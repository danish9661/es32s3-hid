let currentFile = "";
let statusPollTimer = null;
let mouseFlushTimer = null;
let screenshotRefreshTimer = null;
let screenshotObjectUrl = "";
let activeTab = "editor";

const KEY = {
  CTRL: 128,
  SHIFT: 129,
  ALT: 130,
  GUI: 131,
  ENTER: 176,
  ESC: 177,
  BACKSPACE: 178,
  TAB: 179,
  CAPS: 193,
  F1: 194,
  F2: 195,
  F3: 196,
  F4: 197,
  F5: 198,
  F6: 199,
  F7: 200,
  F8: 201,
  F9: 202,
  F10: 203,
  F11: 204,
  F12: 205,
  INSERT: 209,
  HOME: 210,
  PAGE_UP: 211,
  DELETE: 212,
  END: 213,
  PAGE_DOWN: 214,
  RIGHT: 215,
  LEFT: 216,
  DOWN: 217,
  UP: 218,
};

const keyNameMap = {
  backspace: KEY.BACKSPACE,
  delete: KEY.DELETE,
  del: KEY.DELETE,
  left: KEY.LEFT,
  right: KEY.RIGHT,
  up: KEY.UP,
  down: KEY.DOWN,
  enter: KEY.ENTER,
  return: KEY.ENTER,
  tab: KEY.TAB,
  esc: KEY.ESC,
  escape: KEY.ESC,
  insert: KEY.INSERT,
  home: KEY.HOME,
  end: KEY.END,
  pageup: KEY.PAGE_UP,
  pgup: KEY.PAGE_UP,
  pagedown: KEY.PAGE_DOWN,
  pgdn: KEY.PAGE_DOWN,
  space: 32,
  spacebar: 32,
  caps: KEY.CAPS,
  capslock: KEY.CAPS,
};

const tuningHelp = {
  "typing-delay": {
    title: "Typing Delay",
    body: "Delay between each typed character. At 0 ms you hit the raw USB polling limit (~500–1000 chars/sec). Increase if characters are missing on the target system.",
    best: "Ultra Fast: 0 ms · Fast: 2 ms · Balanced: 6 ms · Human: 80 ms.",
  },
  "burst-chars": {
    title: "Burst Characters",
    body: "Characters sent per burst before a short breather pause. Higher = more throughput but risks overflowing the target's input buffer, especially on macOS and in some GUI apps.",
    best: "Ultra Fast: 96 · Fast: 48 · Balanced: 24 · Human: 8.",
  },
  "burst-pause": {
    title: "Burst Pause",
    body: "Pause inserted after each burst of characters. Increase this first when you see dropped chars. macOS needs at least 20 ms at max burst; Windows can usually handle 8 ms.",
    best: "Ultra Fast: 0 ms · Fast: 5 ms · Balanced: 10 ms · Human: 50 ms.",
  },
  "line-delay": {
    title: "Newline Pause",
    body: "Extra pause after every Enter / newline. Critical for CLI shells, Python REPLs, and dialog boxes that need time to process each command line.",
    best: "Ultra Fast: 0 ms · Fast: 10 ms · Balanced: 40 ms · Human: 220 ms.",
  },
};

// Segment order (matches grid-template-columns order in HTML)
const SEG_ORDER = ["ultrafast", "fast", "balanced", "human", "custom"];

const SPEED_PRESETS = {
  ultrafast: { delay: 0,  burst: 96, burstPause: 0,  lineDelay: 0 },
  fast:      { delay: 2,  burst: 48, burstPause: 5,  lineDelay: 10 },
  balanced:  { delay: 6,  burst: 24, burstPause: 10, lineDelay: 40 },
  human:     { delay: 80, burst: 8,  burstPause: 50, lineDelay: 220 },
};

const PRESET_OS_NOTES = {
  ultrafast: "Ultra Fast: Hits raw USB polling limits. Linux handles this well. Windows may drop chars in slow apps (increase Burst Pause to 5 ms). macOS needs Burst Pause >= 15 ms.",
  fast:      "Fast: Reliable on modern Windows 10/11 and Linux. For macOS increase Burst Pause to 15 ms if you see missing characters.",
  balanced:  "Balanced (Default): Safe across Windows, Linux, and macOS for most apps and shells.",
  human:     "Human (~70 WPM): Indistinguishable from real typing on all OS types. Works on kiosks, locked-down terminals, and rate-limited remote desktops.",
  custom:    "Custom: Values set manually. Sliders reflect current live configuration.",
};

let _suppressCustomSwitch = false;

function setPresetSegment(name) {
  const track = qs("speed-seg-track");
  if (!track) return;

  SEG_ORDER.forEach(seg => {
    const btn = qs(`seg-${seg}`);
    if (btn) {
      btn.classList.toggle("active", seg === name);
    }
  });

  // Update OS note
  const note = qs("preset-os-note");
  if (note) {
    const text = PRESET_OS_NOTES[name] || "";
    note.textContent = text;
    note.classList.toggle("visible", !!text);
  }
}

function detectActivePreset(delay, burst, burstPause, lineDelay) {
  for (const [name, p] of Object.entries(SPEED_PRESETS)) {
    if (p.delay === delay && p.burst === burst &&
        p.burstPause === burstPause && p.lineDelay === lineDelay) {
      return name;
    }
  }
  return "custom";
}

function applySpeedPreset(name) {
  const p = SPEED_PRESETS[name];
  if (!p) return;

  _suppressCustomSwitch = true;
  const setSlider = (id, val) => {
    const el = qs(id);
    if (el) { el.value = val; el.dispatchEvent(new Event("input")); }
  };
  setSlider("typing-delay", p.delay);
  setSlider("burst-chars",  p.burst);
  setSlider("burst-pause",  p.burstPause);
  setSlider("line-delay",   p.lineDelay);
  _suppressCustomSwitch = false;

  setPresetSegment(name);
}

function bindSpeedPresets() {
  // Click on any segment button
  SEG_ORDER.forEach(name => {
    const btn = qs(`seg-${name}`);
    if (!btn) return;
    btn.addEventListener("click", () => {
      if (name === "custom") {
        setPresetSegment("custom");
      } else {
        applySpeedPreset(name);
      }
    });
  });

  // Any manual slider touch → switch to Custom
  ["typing-delay", "burst-chars", "burst-pause", "line-delay"].forEach(id => {
    const el = qs(id);
    if (el) el.addEventListener("input", () => {
      if (!_suppressCustomSwitch) setPresetSegment("custom");
    });
  });

  // Set Balanced as default; use requestAnimationFrame so DOM is painted
  requestAnimationFrame(() => setPresetSegment("balanced"));
}

const keyboardLayout = [
  [
    { label: "Esc", code: KEY.ESC, w: 1.3 },
    { label: "`", code: "`".charCodeAt(0) },
    { label: "1", code: "1".charCodeAt(0) },
    { label: "2", code: "2".charCodeAt(0) },
    { label: "3", code: "3".charCodeAt(0) },
    { label: "4", code: "4".charCodeAt(0) },
    { label: "5", code: "5".charCodeAt(0) },
    { label: "6", code: "6".charCodeAt(0) },
    { label: "7", code: "7".charCodeAt(0) },
    { label: "8", code: "8".charCodeAt(0) },
    { label: "9", code: "9".charCodeAt(0) },
    { label: "0", code: "0".charCodeAt(0) },
    { label: "-", code: "-".charCodeAt(0) },
    { label: "=", code: "=".charCodeAt(0) },
    { label: "Backspace", code: KEY.BACKSPACE, w: 2.3 },
    { label: "Ins", code: KEY.INSERT, w: 1.2 },
    { label: "Home", code: KEY.HOME, w: 1.2 },
    { label: "PgUp", code: KEY.PAGE_UP, w: 1.3 },
  ],
  [
    { label: "Tab", code: KEY.TAB, w: 1.7 },
    { label: "Q", code: "q".charCodeAt(0) },
    { label: "W", code: "w".charCodeAt(0) },
    { label: "E", code: "e".charCodeAt(0) },
    { label: "R", code: "r".charCodeAt(0) },
    { label: "T", code: "t".charCodeAt(0) },
    { label: "Y", code: "y".charCodeAt(0) },
    { label: "U", code: "u".charCodeAt(0) },
    { label: "I", code: "i".charCodeAt(0) },
    { label: "O", code: "o".charCodeAt(0) },
    { label: "P", code: "p".charCodeAt(0) },
    { label: "[", code: "[".charCodeAt(0) },
    { label: "]", code: "]".charCodeAt(0) },
    { label: "\\", code: "\\".charCodeAt(0), w: 1.6 },
    { label: "Del", code: KEY.DELETE, w: 1.2 },
    { label: "End", code: KEY.END, w: 1.2 },
    { label: "PgDn", code: KEY.PAGE_DOWN, w: 1.3 },
  ],
  [
    { label: "Caps", code: KEY.CAPS, w: 2.1 },
    { label: "A", code: "a".charCodeAt(0) },
    { label: "S", code: "s".charCodeAt(0) },
    { label: "D", code: "d".charCodeAt(0) },
    { label: "F", code: "f".charCodeAt(0) },
    { label: "G", code: "g".charCodeAt(0) },
    { label: "H", code: "h".charCodeAt(0) },
    { label: "J", code: "j".charCodeAt(0) },
    { label: "K", code: "k".charCodeAt(0) },
    { label: "L", code: "l".charCodeAt(0) },
    { label: ";", code: ";".charCodeAt(0) },
    { label: "'", code: "'".charCodeAt(0) },
    { label: "Enter", code: KEY.ENTER, w: 2.4 },
  ],
  [
    { label: "Shift", code: KEY.SHIFT, w: 2.6 },
    { label: "Z", code: "z".charCodeAt(0) },
    { label: "X", code: "x".charCodeAt(0) },
    { label: "C", code: "c".charCodeAt(0) },
    { label: "V", code: "v".charCodeAt(0) },
    { label: "B", code: "b".charCodeAt(0) },
    { label: "N", code: "n".charCodeAt(0) },
    { label: "M", code: "m".charCodeAt(0) },
    { label: ",", code: ",".charCodeAt(0) },
    { label: ".", code: ".".charCodeAt(0) },
    { label: "/", code: "/".charCodeAt(0) },
    { label: "Shift", code: KEY.SHIFT, w: 2.6 },
    { label: "Up", code: KEY.UP, w: 1.3 },
  ],
  [
    { label: "Ctrl", code: KEY.CTRL, w: 1.6 },
    { label: "Win", code: KEY.GUI, w: 1.4 },
    { label: "Alt", code: KEY.ALT, w: 1.4 },
    { label: "Space", code: 32, w: 6.6 },
    { label: "Alt", code: KEY.ALT, w: 1.4 },
    { label: "Win", code: KEY.GUI, w: 1.4 },
    { label: "Ctrl", code: KEY.CTRL, w: 1.6 },
    { label: "Left", code: KEY.LEFT, w: 1.3 },
    { label: "Down", code: KEY.DOWN, w: 1.3 },
    { label: "Right", code: KEY.RIGHT, w: 1.3 },
  ],
];

const quickActionStorageKey = "esp32_custom_quick_actions_v3";
const keyboardPrefsStorageKey = "esp32_keyboard_prefs_v1";
const preferenceBundleVersion = 1;
const actionFileHeader = "# ESP32-HID-ACTION-V1";

const defaultKeyboardPrefs = {
  tapHoldMs: 35,
  comboHoldMs: 45,
  autoReleaseOnTabSwitch: true,
};

const usbVendorPresets = {
  // Office & Enterprise Peripherals
  dell_kb216: {
    vendorName: "Dell Computer Corp.",
    vid: 0x413C,
    pid: 0x2113,
    productName: "Dell KB216 Multimedia Keyboard",
  },
  dell_ms116: {
    vendorName: "Dell Computer Corp.",
    vid: 0x413C,
    pid: 0x301A,
    productName: "Dell MS116 Optical Mouse",
  },
  logitech_k120: {
    vendorName: "Logitech",
    vid: 0x046D,
    pid: 0xC31C,
    productName: "Logitech K120 Keyboard",
  },
  logitech_unifying: {
    vendorName: "Logitech",
    vid: 0x046D,
    pid: 0xC52B,
    productName: "Logitech USB Unifying Receiver",
  },
  logitech_mx_master: {
    vendorName: "Logitech",
    vid: 0x046D,
    pid: 0xB023,
    productName: "Logitech MX Master 3S",
  },
  hp_standard_kbd: {
    vendorName: "Hewlett-Packard",
    vid: 0x03F0,
    pid: 0x0024,
    productName: "HP Standard Keyboard",
  },
  hp_link_5: {
    vendorName: "Hewlett-Packard",
    vid: 0x03F0,
    pid: 0x134A,
    productName: "HP Link-5 Wireless Receiver",
  },
  lenovo_calliope: {
    vendorName: "Lenovo",
    vid: 0x17EF,
    pid: 0x608D,
    productName: "Lenovo Calliope USB Keyboard",
  },
  lenovo_mouse: {
    vendorName: "Lenovo",
    vid: 0x17EF,
    pid: 0x6082,
    productName: "Lenovo USB Optical Mouse",
  },
  microsoft_basic: {
    vendorName: "Microsoft Corp.",
    vid: 0x045E,
    pid: 0x0752,
    productName: "Microsoft Wired Keyboard 600",
  },
  microsoft_comfort: {
    vendorName: "Microsoft Corp.",
    vid: 0x045E,
    pid: 0x07F8,
    productName: "Microsoft Comfort Optical Mouse 3000",
  },
  apple_magic_kbd: {
    vendorName: "Apple Inc.",
    vid: 0x05AC,
    pid: 0x024F,
    productName: "Apple Magic Keyboard",
  },
  apple_magic_mouse: {
    vendorName: "Apple Inc.",
    vid: 0x05AC,
    pid: 0x030D,
    productName: "Apple Magic Mouse",
  },

  // Gaming Gear & Mechanical Keyboards
  razer_blackwidow: {
    vendorName: "Razer Inc.",
    vid: 0x1532,
    pid: 0x0228,
    productName: "Razer BlackWidow Chroma",
  },
  razer_deathadder: {
    vendorName: "Razer Inc.",
    vid: 0x1532,
    pid: 0x0084,
    productName: "Razer DeathAdder Essential",
  },
  corsair_k70: {
    vendorName: "Corsair",
    vid: 0x1B1C,
    pid: 0x1B09,
    productName: "Corsair K70 RGB Mechanical Keyboard",
  },
  corsair_harpoon: {
    vendorName: "Corsair",
    vid: 0x1B1C,
    pid: 0x1B3C,
    productName: "Corsair Harpoon RGB Gaming Mouse",
  },
  steelseries_apex: {
    vendorName: "SteelSeries",
    vid: 0x1038,
    pid: 0x1610,
    productName: "SteelSeries Apex Pro Keyboard",
  },
  steelseries_rival: {
    vendorName: "SteelSeries",
    vid: 0x1038,
    pid: 0x1702,
    productName: "SteelSeries Rival 300 Gaming Mouse",
  },
  hyperx_alloy: {
    vendorName: "Kingston / HyperX",
    vid: 0x0951,
    pid: 0x16DE,
    productName: "HyperX Alloy FPS Mechanical Keyboard",
  },
  ducky_one_2: {
    vendorName: "DuckyChannel",
    vid: 0x04D9,
    pid: 0xA0CD,
    productName: "Ducky One 2 Mini RGB",
  },
  keychron_q1: {
    vendorName: "Keychron",
    vid: 0x3434,
    pid: 0x0121,
    productName: "Keychron Q1 Mechanical Keyboard",
  },
  wooting_60he: {
    vendorName: "Wooting",
    vid: 0x31E3,
    pid: 0x1301,
    productName: "Wooting 60HE Analog Keyboard",
  },

  // USB Flash Drives & Storage (MSC Mode)
  sandisk_cruzer: {
    vendorName: "SanDisk Corp.",
    vid: 0x0781,
    pid: 0x5567,
    productName: "SanDisk Cruzer Blade 32GB",
  },
  sandisk_ultra: {
    vendorName: "SanDisk Corp.",
    vid: 0x0781,
    pid: 0x5581,
    productName: "SanDisk Ultra USB 3.0",
  },
  kingston_datatraveler: {
    vendorName: "Kingston Technology",
    vid: 0x0951,
    pid: 0x1666,
    productName: "Kingston DataTraveler 3.0",
  },
  samsung_fit: {
    vendorName: "Samsung Electronics",
    vid: 0x04E8,
    pid: 0x61B6,
    productName: "Samsung USB 3.1 Flash Drive FIT",
  },
  transcend_jetflash: {
    vendorName: "Transcend Information",
    vid: 0x058F,
    pid: 0x6387,
    productName: "Transcend JetFlash 700",
  },
  generic_flash: {
    vendorName: "Generic",
    vid: 0x058F,
    pid: 0x1234,
    productName: "Mass Storage Device",
  },

  // Security Tokens & Hardware Development
  yubico_yubikey5: {
    vendorName: "Yubico",
    vid: 0x1050,
    pid: 0x0407,
    productName: "YubiKey 5 Series OTP+FIDO+CCID",
  },
  yubico_security_key: {
    vendorName: "Yubico",
    vid: 0x1050,
    pid: 0x0120,
    productName: "Security Key by Yubico",
  },
  duckypad: {
    vendorName: "dekunukem",
    vid: 0x1209,
    pid: 0xD0C0,
    productName: "duckyPad Pro 15-Key Macro",
  },
  arduino_leonardo: {
    vendorName: "Arduino SA",
    vid: 0x2341,
    pid: 0x8036,
    productName: "Arduino Leonardo HID",
  },
  adafruit_trinket: {
    vendorName: "Adafruit",
    vid: 0x239A,
    pid: 0x8008,
    productName: "Adafruit Trinket M0 Keyboard",
  },
  espressif_s3: {
    vendorName: "Espressif",
    vid: 0x303A,
    pid: 0x0002,
    productName: "ESP32-S3 HID Console",
  },
};

let customQuickActions = [];
let keyboardPrefs = { ...defaultKeyboardPrefs };

const lockedModifiers = new Set();
const pointerPressedKeys = new Map();

const trackpadPointers = new Map();
const mouseAccum = {
  dx: 0,
  dy: 0,
  wheel: 0,
  pan: 0,
};

const recorder = {
  active: false,
  source: "ui",
  bridgeActive: false,
  lastEventAt: 0,
  events: [],
};

const bridgeMouseButtonMasks = [1, 2, 4, 8, 16];

const bridgeModifierMap = [
  { bit: 0x01, code: KEY.CTRL },
  { bit: 0x02, code: KEY.SHIFT },
  { bit: 0x04, code: KEY.ALT },
  { bit: 0x08, code: KEY.GUI },
  { bit: 0x10, code: KEY.CTRL },
  { bit: 0x20, code: KEY.SHIFT },
  { bit: 0x40, code: KEY.ALT },
  { bit: 0x80, code: KEY.GUI },
];

let leftMouseHeld = false;

function qs(id) {
  return document.getElementById(id);
}

function setText(id, text) {
  const el = qs(id);
  if (el) {
    el.textContent = text;
    el.className = "status-line";
  }
}

function setValue(id, val) {
  const el = qs(id);
  if (el) {
    el.value = val;
  }
}

function setStatusMsg(id, text, type = "") {
  const el = qs(id);
  if (!el) return;
  el.textContent = text;
  el.className = "status-line" + (type ? " " + type : "");
}

function clampNumber(value, min, max) {
  const v = Number(value);
  if (!Number.isFinite(v)) return min;
  if (v < min) return min;
  if (v > max) return max;
  return v;
}

function getKvmMouseSmoothScale() {
  const slider = qs("kvm-mouse-smooth");
  const percent = slider ? clampNumber(slider.value, 25, 250) : 100;
  return Number(percent) / 100;
}

function formatHex16(value) {
  const v = clampNumber(value, 0, 0xFFFF);
  return `0x${Math.trunc(v).toString(16).toUpperCase().padStart(4, "0")}`;
}

function parseHexOrDecStrict(rawValue) {
  const raw = String(rawValue ?? "").trim();
  if (!raw) return null;

  const base = raw.toLowerCase().startsWith("0x") ? 16 : 10;
  const parsed = Number.parseInt(raw, base);
  if (!Number.isFinite(parsed)) return null;
  if (parsed < 0 || parsed > 0xFFFF) return null;
  return parsed;
}

function parseHexOrDec(rawValue, fallback) {
  const parsed = parseHexOrDecStrict(rawValue);
  return parsed == null ? fallback : parsed;
}

function downloadTextFile(filename, content, mimeType = "text/plain") {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function escapeHtml(str) {
  if (str == null) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

async function copyTextToClipboard(text, successLabel = "Copied.") {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      setText("kvm-status", successLabel);
      return;
    }
  } catch (_) {}

  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.focus();
  ta.select();
  try {
    document.execCommand("copy");
    setText("kvm-status", successLabel);
  } catch (_) {
    setText("kvm-status", "Copy failed. Please copy manually.");
  } finally {
    document.body.removeChild(ta);
  }
}

async function api(path, options = {}) {
  const response = await fetch(path, options);

  if (response.status === 401) {
    window.location.href = "/login";
    throw new Error("unauthorized");
  }

  return response;
}

function updateRunBadge(busy) {
  const badge = qs("run-state");
  if (!badge) return;

  if (busy) {
    badge.className = "badge busy";
    badge.textContent = "Typing in progress";
  } else {
    badge.className = "badge ok";
    badge.textContent = "Ready";
  }
}

function updateNetworkInfo(d) {
  if (!d) return;

  const staConnected = Boolean(d.sta_connected);
  const staIp = d.sta_ip || "";
  const apIp = d.ap_ip || "192.168.4.1";

  const topIp = qs("topbar-ip-badge");
  if (topIp) {
    if (staConnected && staIp) {
      topIp.textContent = "Home IP: " + staIp;
      topIp.className = "badge badge-ip";
    } else {
      topIp.textContent = "AP: " + apIp;
      topIp.className = "badge";
    }
  }

  const netStaIp = qs("net-sta-ip");
  const netStaStatus = qs("net-sta-status");
  const btnCopySta = qs("net-copy-sta-ip");
  const btnOpenSta = qs("net-open-sta-ip");

  if (netStaIp) {
    if (staConnected && staIp) {
      netStaIp.textContent = staIp;
      netStaIp.className = "net-ip";
      if (netStaStatus) {
        netStaStatus.textContent = "Connected" + (d.sta_rssi ? ` (${d.sta_rssi} dBm)` : "");
        netStaStatus.style.color = "#44c08a";
      }
      if (btnCopySta) btnCopySta.disabled = false;
      if (btnOpenSta) btnOpenSta.disabled = false;
    } else {
      netStaIp.textContent = "Not Connected";
      netStaIp.className = "net-ip disconnected";
      if (netStaStatus) {
        netStaStatus.textContent = d.sta_ssid ? "Status: Disconnected / Retrying" : "Status: No Router Configured";
        netStaStatus.style.color = "";
      }
      if (btnCopySta) btnCopySta.disabled = true;
      if (btnOpenSta) btnOpenSta.disabled = true;
    }
  }

  if (qs("net-ap-ip")) qs("net-ap-ip").textContent = apIp;
  if (qs("net-mdns") && d.mdns_host) qs("net-mdns").textContent = d.mdns_host;
  if (qs("net-mac") && d.mac_address) qs("net-mac").textContent = d.mac_address;
  if (qs("net-signal") && typeof d.sta_rssi !== "undefined") {
    qs("net-signal").textContent = staConnected ? `Signal: ${d.sta_rssi} dBm` : "Signal: N/A";
  }
  if (qs("net-gateway") && d.sta_gateway) {
    qs("net-gateway").textContent = `Gateway: ${d.sta_gateway}`;
  }
}

function updateScriptProgress(d) {
  const box = qs("script-progress-box");
  const bar = qs("script-progress-bar");
  const text = qs("script-progress-text");
  const cmd = qs("script-progress-cmd");
  if (!box || !bar || !text || !cmd) return;

  const busy = Boolean(d.busy || d.queued);
  if (busy && (d.line_total > 0 || d.progress > 0)) {
    box.classList.remove("hidden");
    const pct = d.progress || 0;
    bar.style.width = pct + "%";
    if (d.line_total > 0) {
      text.textContent = `Executing line ${d.line_current || 0}/${d.line_total} (${pct}%)`;
    } else {
      text.textContent = `Typing in progress (${pct}%)`;
    }
    cmd.textContent = d.current_cmd ? d.current_cmd : "";
  } else if (!busy) {
    box.classList.add("hidden");
    bar.style.width = "0%";
  }
}

async function refreshStatus() {
  try {
    const res = await api("/api/status");
    if (!res.ok) return;
    const data = await res.json();
    updateRunBadge(Boolean(data.busy || data.queued));
    updateNetworkInfo(data);
    updateScriptProgress(data);
  } catch (_) {}
}

async function loadFiles() {
  try {
    const res = await api("/api/list");
    if (!res.ok) {
      setText("editor-status", "Failed to load files.");
      return;
    }

    const files = await res.json();
    const list = qs("files-list");
    list.innerHTML = "";

    if (!files.length) {
      list.innerHTML = '<div class="small">No scripts yet.</div>';
      return;
    }

    files
      .sort((a, b) => a.name.localeCompare(b.name))
      .forEach((file) => {
        const btn = document.createElement("button");
        btn.className = "file-item" + (file.name === currentFile ? " active" : "");
        btn.textContent = file.name;
        btn.title = `${file.name} (${file.size} bytes)`;
        btn.addEventListener("click", () => loadFile(file.name));
        list.appendChild(btn);
      });
  } catch (_) {
    setText("editor-status", "Connection error while listing files.");
  }
}

async function loadFile(name) {
  try {
    const res = await api(`/api/load?name=${encodeURIComponent(name)}`);
    if (!res.ok) {
      setText("editor-status", "Failed to load script.");
      return;
    }

    const text = await res.text();
    currentFile = name;
    qs("code-area").value = text;
    setText("current-file", name);
    setText("editor-status", "Script loaded.");
    loadFiles();
  } catch (_) {
    setText("editor-status", "Network error while loading script.");
  }
}

async function loadMscFiles() {
  const list = qs("msc-files-list");
  if (!list) return;
  try {
    const res = await api("/api/usb_drive/files");
    if (!res.ok) {
      list.innerHTML = '<div style="color:var(--danger); font-size:11px;">USB Drive unavailable</div>';
      return;
    }
    const data = await res.json();
    const usedBytes = data.used_bytes || 0;
    const totalBytes = data.total_bytes || (2 * 1024 * 1024);
    const usedKb = (usedBytes / 1024).toFixed(0);
    const totalKb = (totalBytes / 1024).toFixed(0);
    const pct = Math.min(100, Math.round((usedBytes / totalBytes) * 100));

    const usageBar = qs("msc-usage-bar");
    if (usageBar) usageBar.style.width = `${pct}%`;
    setText("msc-usage-text", `${usedKb} KB / ${totalKb} KB`);
    setText("msc-percent-text", `${pct}%`);

    list.innerHTML = "";
    if (!data.files || !data.files.length) {
      list.innerHTML = '<div style="color:var(--muted); font-size:11px;">No files on USB drive.</div>';
      return;
    }

    data.files.forEach((f) => {
      const row = document.createElement("div");
      row.style.cssText = "display:flex; justify-content:space-between; align-items:center; padding:4px 6px; background:rgba(255,255,255,0.03); border-radius:4px; transition:background 0.12s;";
      
      const nameSpan = document.createElement("span");
      nameSpan.textContent = f.name;
      nameSpan.title = `Click to load ${f.name} in editor (${f.size} bytes)`;
      nameSpan.style.cssText = "overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:115px; cursor:pointer; color:#00f3ff;";
      nameSpan.addEventListener("click", async () => {
        try {
          setText("editor-status", `Loading ${f.name} from USB Drive...`);
          const r = await api(`/api/usb_drive/read?name=${encodeURIComponent(f.name)}`);
          if (r.ok) {
            const txt = await r.text();
            currentFile = f.name;
            qs("code-area").value = txt;
            setText("current-file", `USB: ${f.name}`);
            setText("editor-status", `Loaded ${f.name} from USB drive.`);
          }
        } catch (_) {
          setText("editor-status", `Failed to load ${f.name}`);
        }
      });

      const rightDiv = document.createElement("div");
      rightDiv.style.cssText = "display:flex; align-items:center; gap:6px;";

      const sizeSpan = document.createElement("span");
      sizeSpan.style.cssText = "color:var(--muted); font-size:10px;";
      sizeSpan.textContent = f.size > 1024 ? `${(f.size / 1024).toFixed(1)}K` : `${f.size}B`;

      const delBtn = document.createElement("button");
      delBtn.className = "btn-danger btn-sm";
      delBtn.style.cssText = "padding:1px 4px; font-size:10px; line-height:1;";
      delBtn.textContent = "✕";
      delBtn.title = `Delete ${f.name} from USB Drive`;
      delBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        deleteUsbDriveFile(f.name);
      });

      rightDiv.appendChild(sizeSpan);
      rightDiv.appendChild(delBtn);
      row.appendChild(nameSpan);
      row.appendChild(rightDiv);
      list.appendChild(row);
    });
  } catch (_) {
    list.innerHTML = '<div style="color:var(--muted); font-size:11px;">Error loading drive files</div>';
  }
}

async function stageCurrentScriptToMsc() {
  if (!currentFile) {
    alert("Please select or save a script in the editor first.");
    return;
  }
  setText("msc-status-line", `Staging ${currentFile}...`);
  try {
    const res = await api(`/api/usb_drive/stage_script?name=${encodeURIComponent(currentFile)}`, { method: "POST" });
    const data = await res.json();
    if (res.ok && data.ok) {
      setText("msc-status-line", `✅ Staged to PAYLOAD.PS1`);
      loadMscFiles();
    } else {
      setText("msc-status-line", `❌ ${data.error || "Failed to stage"}`);
    }
  } catch (_) {
    setText("msc-status-line", "❌ Network error");
  }
}

async function rebuildUsbDrive() {
  setText("msc-status-line", "Rebuilding FAT12 drive...");
  try {
    const res = await api("/api/usb_drive/rebuild", { method: "POST" });
    const data = await res.json();
    setText("msc-status-line", data.ok ? "✅ Drive rebuilt" : `⚠️ ${data.message || "Not active"}`);
    if (data.ok) loadMscFiles();
  } catch (_) {
    setText("msc-status-line", "❌ Network error");
  }
}

async function resetMscDefault() {
  if (!confirm("Reset USB Drive to factory default files? All custom files will be deleted.")) return;
  setText("msc-status-line", "Resetting USB Drive...");
  try {
    const res = await api("/api/usb_drive/reset", { method: "POST" });
    const data = await res.json();
    if (res.ok && data.ok) {
      setText("msc-status-line", "✅ USB Drive reset to default");
      loadMscFiles();
    } else {
      setText("msc-status-line", `❌ ${data.error || "Failed to reset"}`);
    }
  } catch (_) {
    setText("msc-status-line", "❌ Network error");
  }
}

async function deleteUsbDriveFile(name) {
  if (!confirm(`Delete '${name}' from USB Drive?`)) return;
  try {
    const res = await api(`/api/usb_drive/delete?name=${encodeURIComponent(name)}`, { method: "POST" });
    const data = await res.json();
    if (res.ok && data.ok) {
      setText("msc-status-line", `Deleted ${name}`);
      loadMscFiles();
    } else {
      alert(data.error || "Failed to delete file from USB drive");
    }
  } catch (_) {
    alert("Network error while deleting file");
  }
}




function askNewFilename() {
  const name = prompt("New script name (example: demo.txt)", "demo.txt");
  if (!name) return "";
  const cleaned = name.trim();
  if (!/^[a-zA-Z0-9_.\- ]{1,64}$/.test(cleaned)) {
    alert("Allowed characters: letters, numbers, space, _, -, .");
    return "";
  }
  return cleaned;
}

function createNewFile() {
  const name = askNewFilename();
  if (!name) return;

  currentFile = name;
  qs("code-area").value = "GUI r\nDELAY 450\nSTRING notepad\nENTER\nDELAY 250\nSTRING Hello from ESP32-S3";
  setText("current-file", currentFile);
  setText("editor-status", "New file ready. Click Save.");
  loadFiles();
}

async function saveCurrentFile() {
  if (!currentFile) {
    createNewFile();
    if (!currentFile) return;
  }

  const content = qs("code-area").value;
  const body = new FormData();
  body.append("data", new Blob([content], { type: "text/plain" }), currentFile);

  try {
    const res = await api("/api/edit", { method: "POST", body });
    if (!res.ok) {
      setText("editor-status", "Save failed.");
      return;
    }

    setText("editor-status", "Saved.");
    loadFiles();
  } catch (_) {
    setText("editor-status", "Network error while saving.");
  }
}

async function deleteCurrentFile() {
  if (!currentFile) return;
  if (!confirm(`Delete ${currentFile}?`)) return;

  try {
    const res = await api(`/api/delete?name=${encodeURIComponent(currentFile)}`, {
      method: "DELETE",
    });
    if (!res.ok) {
      setText("editor-status", "Delete failed.");
      return;
    }

    currentFile = "";
    qs("code-area").value = "";
    setText("current-file", "No file selected");
    setText("editor-status", "Deleted.");
    loadFiles();
  } catch (_) {
    setText("editor-status", "Network error while deleting.");
  }
}

function downloadCurrentFile() {
  if (!currentFile) return;
  downloadTextFile(currentFile, qs("code-area").value, "text/plain");
}

async function runScript() {
  const code = qs("code-area").value;
  if (!code.trim()) return;

  setText("editor-status", "Queueing script...");
  try {
    const res = await api("/api/run", { method: "POST", body: code });
    if (!res.ok) {
      setText("editor-status", "Device busy or failed to queue.");
      return;
    }

    setText("editor-status", "Script queued.");
    refreshStatus();
  } catch (_) {
    setText("editor-status", "Network error while running script.");
  }
}

async function stopScript() {
  try {
    await api("/api/stop", { method: "POST" });
    setText("editor-status", "Stop signal sent.");
    setText("remote-status", "Stop signal sent.");
    refreshStatus();
  } catch (_) {
    setText("editor-status", "Failed to send stop signal.");
  }
}

async function injectLiveText() {
  const text = qs("live-text").value;
  if (!text) return;

  setText("remote-status", "Queueing text...");
  qs("inject-btn").disabled = true;

  try {
    const res = await api("/api/live_text", { method: "POST", body: text });
    if (!res.ok) {
      setText("remote-status", "Busy or failed to queue text.");
      return;
    }

    setText("remote-status", "Text queued.");
    qs("live-text").value = "";
    refreshStatus();
  } catch (_) {
    setText("remote-status", "Network error while queueing text.");
  } finally {
    qs("inject-btn").disabled = false;
  }
}

function parseKeyToken(token) {
  const lower = token.toLowerCase().trim();
  if (!lower) return null;

  if (Object.prototype.hasOwnProperty.call(keyNameMap, lower)) {
    return keyNameMap[lower];
  }

  const fnMatch = lower.match(/^f([1-9]|1[0-2])$/);
  if (fnMatch) {
    const fnNumber = Number(fnMatch[1]);
    return KEY.F1 + (fnNumber - 1);
  }

  if (lower.length === 1) {
    return lower.charCodeAt(0);
  }

  return null;
}

function modsToFlags(mods) {
  return (mods.ctrl ? 1 : 0)
    | (mods.alt ? 2 : 0)
    | (mods.shift ? 4 : 0)
    | (mods.gui ? 8 : 0);
}

function parseComboString(combo) {
  const rawParts = combo
    .toLowerCase()
    .split("+")
    .map((s) => s.trim())
    .filter(Boolean);

  if (!rawParts.length) return null;

  const mods = {
    ctrl: false,
    alt: false,
    shift: false,
    gui: false,
  };

  const lastToken = rawParts[rawParts.length - 1];
  for (let i = 0; i < rawParts.length - 1; i++) {
    const part = rawParts[i];
    if (part === "ctrl" || part === "control") mods.ctrl = true;
    else if (part === "alt" || part === "option") mods.alt = true;
    else if (part === "shift") mods.shift = true;
    else if (part === "gui" || part === "win" || part === "meta" || part === "cmd") mods.gui = true;
  }

  const code = parseKeyToken(lastToken);
  if (code == null) return null;

  return { mods, code, keyToken: lastToken };
}

function recordActionEvent(type, payload = {}) {
  if (!recorder.active || recorder.source !== "ui") return;

  const now = Date.now();
  const delay = recorder.lastEventAt > 0
    ? clampNumber(now - recorder.lastEventAt, 0, 60000)
    : 0;

  recorder.lastEventAt = now;
  recorder.events.push({
    delay: Math.trunc(delay),
    type,
    ...payload,
  });

  if (recorder.events.length > 8000) {
    recorder.active = false;
    setText("record-status", "Recorder stopped: max 8000 events reached.");
    return;
  }

  setText("record-status", `Recording... ${recorder.events.length} events`);
}

async function sendKeyTap(code, hold = keyboardPrefs.tapHoldMs, shouldRecord = true) {
  const safeHold = Math.trunc(clampNumber(hold, 10, 300));

  try {
    const res = await api("/api/live_key", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, hold: safeHold }),
    });

    if (!res.ok) {
      setText("remote-status", "Key send failed (busy or invalid).");
      return false;
    }

    if (shouldRecord) {
      recordActionEvent("key_tap", { code, hold: safeHold });
    }
    setText("remote-status", `Key sent: ${code}`);
    return true;
  } catch (_) {
    setText("remote-status", "Network error while sending key.");
    return false;
  }
}

async function sendCombo(combo, hold = keyboardPrefs.comboHoldMs, shouldRecord = true) {
  const parsed = parseComboString(combo);
  if (!parsed) {
    setText("remote-status", "Invalid combo.");
    return false;
  }

  const safeHold = Math.trunc(clampNumber(hold, 10, 300));
  const payload = {
    ...parsed.mods,
    code: parsed.code,
    hold: safeHold,
  };

  try {
    const res = await api("/api/live_combo", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      setText("remote-status", "Combo failed (busy or invalid).");
      return false;
    }

    if (shouldRecord) {
      recordActionEvent("combo", {
        flags: modsToFlags(parsed.mods),
        code: parsed.code,
        hold: safeHold,
      });
    }
    setText("remote-status", `Combo sent: ${combo}`);
    return true;
  } catch (_) {
    setText("remote-status", "Network error while sending combo.");
    return false;
  }
}

async function sendKeyboardEvent(action, code = null, hold = null, shouldRecord = true) {
  const payload = { action };
  if (code != null) payload.code = Number(code);
  if (hold != null) payload.hold = Math.trunc(clampNumber(hold, 10, 300));

  const res = await api("/api/kbd_event", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (res.ok && shouldRecord) {
    if (action === "down") {
      recordActionEvent("key_down", { code: Number(code) });
    } else if (action === "up") {
      recordActionEvent("key_up", { code: Number(code) });
    } else if (action === "release_all") {
      recordActionEvent("key_release_all", {});
    } else if (action === "tap") {
      recordActionEvent("key_tap", {
        code: Number(code),
        hold: payload.hold || keyboardPrefs.tapHoldMs,
      });
    }
  }

  return res.ok;
}

function loadCustomActions() {
  try {
    const raw = localStorage.getItem(quickActionStorageKey);
    if (!raw) {
      customQuickActions = [];
      return;
    }

    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      customQuickActions = [];
      return;
    }

    customQuickActions = parsed
      .filter((item) => item && typeof item.label === "string" && typeof item.combo === "string")
      .map((item) => ({
        label: item.label.trim().slice(0, 40),
        combo: item.combo.trim().slice(0, 50),
      }))
      .filter((item) => item.label.length > 0 && item.combo.length > 0)
      .slice(0, 80);
  } catch (_) {
    customQuickActions = [];
  }
}

function saveCustomActions() {
  localStorage.setItem(quickActionStorageKey, JSON.stringify(customQuickActions));
}

function loadKeyboardPrefs() {
  try {
    const raw = localStorage.getItem(keyboardPrefsStorageKey);
    if (!raw) {
      keyboardPrefs = { ...defaultKeyboardPrefs };
      return;
    }

    const parsed = JSON.parse(raw);
    keyboardPrefs = {
      tapHoldMs: Math.trunc(clampNumber(parsed.tapHoldMs, 10, 180)),
      comboHoldMs: Math.trunc(clampNumber(parsed.comboHoldMs, 10, 220)),
      autoReleaseOnTabSwitch: Boolean(parsed.autoReleaseOnTabSwitch),
    };
  } catch (_) {
    keyboardPrefs = { ...defaultKeyboardPrefs };
  }
}

function saveKeyboardPrefs() {
  localStorage.setItem(keyboardPrefsStorageKey, JSON.stringify(keyboardPrefs));
}

function updateKeyboardPrefReadout(id, unit = "") {
  const input = qs(id);
  const out = qs(`${id}-value`);
  if (!input || !out) return;
  out.textContent = `${input.value}${unit}`;
}

function applyKeyboardPrefsToUI() {
  qs("kbd-pref-tap-hold").value = String(keyboardPrefs.tapHoldMs);
  qs("kbd-pref-combo-hold").value = String(keyboardPrefs.comboHoldMs);
  qs("kbd-pref-auto-release").checked = Boolean(keyboardPrefs.autoReleaseOnTabSwitch);
  updateKeyboardPrefReadout("kbd-pref-tap-hold", " ms");
  updateKeyboardPrefReadout("kbd-pref-combo-hold", " ms");
}

function bindKeyboardPreferenceControls() {
  const tap = qs("kbd-pref-tap-hold");
  const combo = qs("kbd-pref-combo-hold");
  const autoRelease = qs("kbd-pref-auto-release");

  tap.addEventListener("input", () => {
    keyboardPrefs.tapHoldMs = Math.trunc(clampNumber(tap.value, 10, 180));
    updateKeyboardPrefReadout("kbd-pref-tap-hold", " ms");
    saveKeyboardPrefs();
    setText("kbd-pref-status", "Keyboard preferences saved locally.");
  });

  combo.addEventListener("input", () => {
    keyboardPrefs.comboHoldMs = Math.trunc(clampNumber(combo.value, 10, 220));
    updateKeyboardPrefReadout("kbd-pref-combo-hold", " ms");
    saveKeyboardPrefs();
    setText("kbd-pref-status", "Keyboard preferences saved locally.");
  });

  autoRelease.addEventListener("change", () => {
    keyboardPrefs.autoReleaseOnTabSwitch = autoRelease.checked;
    saveKeyboardPrefs();
    setText("kbd-pref-status", "Keyboard preferences saved locally.");
  });
}

function exportPreferenceBundle() {
  const payload = {
    version: preferenceBundleVersion,
    exportedAt: new Date().toISOString(),
    customQuickActions,
    keyboardPrefs,
  };

  downloadTextFile("esp32-hid-preferences.json", JSON.stringify(payload, null, 2), "application/json");
  setText("remote-status", "Preferences exported.");
}

async function importPreferenceBundle(file) {
  const text = await file.text();
  const parsed = JSON.parse(text);

  if (!parsed || typeof parsed !== "object") {
    throw new Error("Invalid preferences file.");
  }

  if (Array.isArray(parsed.customQuickActions)) {
    customQuickActions = parsed.customQuickActions
      .filter((item) => item && typeof item.label === "string" && typeof item.combo === "string")
      .map((item) => ({
        label: item.label.trim().slice(0, 40),
        combo: item.combo.trim().slice(0, 50),
      }))
      .filter((item) => item.label.length > 0 && item.combo.length > 0)
      .slice(0, 80);
  }

  if (parsed.keyboardPrefs && typeof parsed.keyboardPrefs === "object") {
    keyboardPrefs = {
      tapHoldMs: Math.trunc(clampNumber(parsed.keyboardPrefs.tapHoldMs, 10, 180)),
      comboHoldMs: Math.trunc(clampNumber(parsed.keyboardPrefs.comboHoldMs, 10, 220)),
      autoReleaseOnTabSwitch: Boolean(parsed.keyboardPrefs.autoReleaseOnTabSwitch),
    };
  }

  saveCustomActions();
  saveKeyboardPrefs();
  renderCustomActions();
  applyKeyboardPrefsToUI();
  setText("remote-status", "Preferences imported.");
}

function renderCustomActions() {
  const container = qs("custom-actions-list");
  container.innerHTML = "";

  if (!customQuickActions.length) {
    container.innerHTML = '<div class="small">No custom actions yet.</div>';
    return;
  }

  customQuickActions.forEach((item, index) => {
    const wrap = document.createElement("div");
    wrap.className = "custom-action-item";

    const trigger = document.createElement("button");
    trigger.className = "key";
    trigger.textContent = item.label;
    trigger.title = item.combo;
    trigger.addEventListener("click", () => sendCombo(item.combo));

    const remove = document.createElement("button");
    remove.className = "remove-action-btn";
    remove.textContent = "x";
    remove.title = "Remove";
    remove.addEventListener("click", () => {
      customQuickActions.splice(index, 1);
      saveCustomActions();
      renderCustomActions();
    });

    wrap.appendChild(trigger);
    wrap.appendChild(remove);
    container.appendChild(wrap);
  });
}

function addCustomAction() {
  const label = qs("custom-action-label").value.trim();
  const combo = qs("custom-action-combo").value.trim();

  if (!label || !combo) {
    alert("Enter both label and shortcut.");
    return;
  }

  const parsed = parseComboString(combo);
  if (!parsed) {
    alert("Invalid shortcut key.");
    return;
  }

  customQuickActions.push({ label: label.slice(0, 40), combo: combo.slice(0, 50) });
  saveCustomActions();
  renderCustomActions();

  qs("custom-action-label").value = "";
  qs("custom-action-combo").value = "";
}

function renderKeyboard65() {
  const root = qs("keyboard-65");
  root.innerHTML = "";

  keyboardLayout.forEach((row) => {
    const rowEl = document.createElement("div");
    rowEl.className = "keyboard-row";

    row.forEach((keyDef) => {
      const keyEl = document.createElement("button");
      keyEl.className = "vk-key";
      keyEl.textContent = keyDef.label;
      keyEl.style.flexGrow = String(keyDef.w || 1);

      if (keyDef.code == null) {
        keyEl.disabled = true;
        keyEl.classList.add("disabled");
      } else {
        keyEl.dataset.code = String(keyDef.code);

        keyEl.addEventListener("pointerdown", (event) => {
          event.preventDefault();
          if (pointerPressedKeys.has(event.pointerId)) return;

          const code = Number(keyEl.dataset.code);
          sendKeyboardEvent("down", code, null, true)
            .then((ok) => {
              if (!ok) return;

              pointerPressedKeys.set(event.pointerId, { code, keyEl, label: keyDef.label });
              keyEl.classList.add("active");
              try {
                keyEl.setPointerCapture(event.pointerId);
              } catch (_) {}
              setText("keyboard-status", `Key down: ${keyDef.label}`);
            })
            .catch(() => {
              setText("keyboard-status", "Keyboard event failed.");
            });
        });

        const release = (pointerId) => {
          const active = pointerPressedKeys.get(pointerId);
          if (!active) return;

          pointerPressedKeys.delete(pointerId);
          active.keyEl.classList.remove("active");

          sendKeyboardEvent("up", active.code, null, true)
            .then(() => {
              setText("keyboard-status", `Key up: ${active.label}`);
            })
            .catch(() => {
              setText("keyboard-status", "Keyboard release failed.");
            });
        };

        keyEl.addEventListener("pointerup", (event) => release(event.pointerId));
        keyEl.addEventListener("pointercancel", (event) => release(event.pointerId));
        keyEl.addEventListener("lostpointercapture", (event) => release(event.pointerId));
      }

      rowEl.appendChild(keyEl);
    });

    root.appendChild(rowEl);
  });
}

function bindModifierLocks() {
  document.querySelectorAll(".mod-lock").forEach((button) => {
    button.addEventListener("click", async () => {
      const code = Number(button.dataset.modCode);
      if (!Number.isFinite(code)) return;

      if (lockedModifiers.has(code)) {
        try {
          await sendKeyboardEvent("up", code, null, true);
          lockedModifiers.delete(code);
          button.classList.remove("active");
          setText("keyboard-status", "Modifier unlocked.");
        } catch (_) {
          setText("keyboard-status", "Failed to unlock modifier.");
        }
      } else {
        try {
          await sendKeyboardEvent("down", code, null, true);
          lockedModifiers.add(code);
          button.classList.add("active");
          setText("keyboard-status", "Modifier locked.");
        } catch (_) {
          setText("keyboard-status", "Failed to lock modifier.");
        }
      }
    });
  });

  qs("release-all-keys-btn").addEventListener("click", async () => {
    try {
      await sendKeyboardEvent("release_all", null, null, true);
      lockedModifiers.clear();
      pointerPressedKeys.clear();
      document.querySelectorAll(".mod-lock").forEach((btn) => btn.classList.remove("active"));
      document.querySelectorAll(".vk-key.active").forEach((btn) => btn.classList.remove("active"));
      setText("keyboard-status", "All keys released.");
    } catch (_) {
      setText("keyboard-status", "Failed to release all keys.");
    }
  });
}

function buttonNameToMask(name) {
  const v = String(name || "").toLowerCase();
  if (v === "left") return 1;
  if (v === "right") return 2;
  if (v === "middle") return 4;
  if (v === "backward") return 8;
  if (v === "forward") return 16;
  return 1;
}

function mouseActionToCode(action) {
  if (action === "down") return 1;
  if (action === "up") return 2;
  return 0;
}

function startMouseFlushLoop() {
  if (mouseFlushTimer) return;

  mouseFlushTimer = setInterval(() => {
    const dx = Math.trunc(mouseAccum.dx);
    const dy = Math.trunc(mouseAccum.dy);
    const wheel = Math.trunc(mouseAccum.wheel);
    const pan = Math.trunc(mouseAccum.pan);

    if (dx !== 0 || dy !== 0) {
      mouseAccum.dx -= dx;
      mouseAccum.dy -= dy;

      api("/api/mouse_move", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dx, dy }),
      })
        .then((res) => {
          if (res.ok) recordActionEvent("mouse_move", { dx, dy });
        })
        .catch(() => {});
    }

    if (wheel !== 0 || pan !== 0) {
      mouseAccum.wheel -= wheel;
      mouseAccum.pan -= pan;

      api("/api/mouse_scroll", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ wheel, pan }),
      })
        .then((res) => {
          if (res.ok) recordActionEvent("mouse_scroll", { wheel, pan });
        })
        .catch(() => {});
    }
  }, 28);
}

function bindTrackpad() {
  const trackpad = qs("trackpad");

  trackpad.addEventListener("pointerdown", (event) => {
    trackpad.setPointerCapture(event.pointerId);
    trackpadPointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
    setText("mouse-status", "Trackpad active.");
  });

  trackpad.addEventListener("pointermove", (event) => {
    if (!trackpadPointers.has(event.pointerId)) return;

    const prev = trackpadPointers.get(event.pointerId);
    const dx = event.clientX - prev.x;
    const dy = event.clientY - prev.y;
    const smoothScale = getKvmMouseSmoothScale();

    trackpadPointers.set(event.pointerId, { x: event.clientX, y: event.clientY });

    if (trackpadPointers.size >= 2) {
      mouseAccum.wheel += (-dy * 0.2 * smoothScale);
      setText("mouse-status", "Gesture scroll.");
    } else {
      mouseAccum.dx += (dx * 1.45 * smoothScale);
      mouseAccum.dy += (dy * 1.45 * smoothScale);
      setText("mouse-status", "Pointer move.");
    }
  });

  const endPointer = (event) => {
    trackpadPointers.delete(event.pointerId);
    if (trackpadPointers.size === 0) {
      setText("mouse-status", "Mouse idle.");
    }
  };

  trackpad.addEventListener("pointerup", endPointer);
  trackpad.addEventListener("pointercancel", endPointer);

  qs("mouse-left-btn").addEventListener("click", async () => {
    try {
      const res = await api("/api/mouse_button", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ button: "left", action: "click" }),
      });
      if (!res.ok) throw new Error();

      recordActionEvent("mouse_button", { button: 1, action: 0 });
      setText("mouse-status", "Left click sent.");
    } catch (_) {
      setText("mouse-status", "Left click failed.");
    }
  });

  qs("mouse-right-btn").addEventListener("click", async () => {
    try {
      const res = await api("/api/mouse_button", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ button: "right", action: "click" }),
      });
      if (!res.ok) throw new Error();

      recordActionEvent("mouse_button", { button: 2, action: 0 });
      setText("mouse-status", "Right click sent.");
    } catch (_) {
      setText("mouse-status", "Right click failed.");
    }
  });

  qs("mouse-left-hold-btn").addEventListener("click", async () => {
    try {
      if (!leftMouseHeld) {
        const res = await api("/api/mouse_button", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ button: "left", action: "down" }),
        });
        if (!res.ok) throw new Error();

        leftMouseHeld = true;
        qs("mouse-left-hold-btn").textContent = "Release Left";
        recordActionEvent("mouse_button", { button: 1, action: 1 });
        setText("mouse-status", "Left button held.");
      } else {
        const res = await api("/api/mouse_button", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ button: "left", action: "up" }),
        });
        if (!res.ok) throw new Error();

        leftMouseHeld = false;
        qs("mouse-left-hold-btn").textContent = "Hold Left";
        recordActionEvent("mouse_button", { button: 1, action: 2 });
        setText("mouse-status", "Left button released.");
      }
    } catch (_) {
      setText("mouse-status", "Mouse hold action failed.");
    }
  });

  qs("mouse-release-btn").addEventListener("click", async () => {
    try {
      await api("/api/mouse_button", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ button: "left", action: "up" }),
      });
      await api("/api/mouse_button", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ button: "right", action: "up" }),
      });
      leftMouseHeld = false;
      qs("mouse-left-hold-btn").textContent = "Hold Left";
      recordActionEvent("mouse_button", { button: 1, action: 2 });
      recordActionEvent("mouse_button", { button: 2, action: 2 });
      setText("mouse-status", "Buttons released.");
    } catch (_) {
      setText("mouse-status", "Failed to release buttons.");
    }
  });
}

let absCoords = { x: 50.0, y: 50.0 };

function bindAbsoluteMouse() {
  const modeRelBtn = qs("mouse-mode-rel");
  const modeAbsBtn = qs("mouse-mode-abs");
  const trackpad = qs("trackpad");
  const absContainer = qs("abs-mouse-container");
  const modeDesc = qs("mouse-mode-desc");
  const absCanvas = qs("abs-canvas");
  const crosshair = qs("abs-crosshair");
  const coordText = qs("abs-coord-text");

  if (!modeRelBtn || !modeAbsBtn || !trackpad || !absContainer) return;

  modeRelBtn.addEventListener("click", () => {
    modeRelBtn.className = "btn-primary btn-sm";
    modeAbsBtn.className = "btn-outline btn-sm";
    trackpad.classList.remove("hidden");
    absContainer.classList.add("hidden");
    if (modeDesc) modeDesc.textContent = "Use trackpad area for relative pointer movement. Two-finger drag sends vertical scrolling.";
  });

  modeAbsBtn.addEventListener("click", () => {
    modeAbsBtn.className = "btn-primary btn-sm";
    modeRelBtn.className = "btn-outline btn-sm";
    trackpad.classList.add("hidden");
    absContainer.classList.remove("hidden");
    if (modeDesc) modeDesc.textContent = "Click or drag on the canvas to set absolute pointer screen coordinates (0% to 100%).";
  });

  const updateCrosshair = (event) => {
    if (!absCanvas || !crosshair) return;
    const rect = absCanvas.getBoundingClientRect();
    let x = ((event.clientX - rect.left) / rect.width) * 100.0;
    let y = ((event.clientY - rect.top) / rect.height) * 100.0;
    x = Math.max(0, Math.min(100, x));
    y = Math.max(0, Math.min(100, y));
    absCoords.x = Math.round(x * 10) / 10;
    absCoords.y = Math.round(y * 10) / 10;

    crosshair.style.left = absCoords.x + "%";
    crosshair.style.top = absCoords.y + "%";
    if (coordText) coordText.textContent = `X: ${absCoords.x.toFixed(1)}%, Y: ${absCoords.y.toFixed(1)}%`;
  };

  let isDraggingAbs = false;
  absCanvas?.addEventListener("pointerdown", (e) => {
    isDraggingAbs = true;
    absCanvas.setPointerCapture(e.pointerId);
    updateCrosshair(e);
  });
  absCanvas?.addEventListener("pointermove", (e) => {
    if (isDraggingAbs) updateCrosshair(e);
  });
  const endAbsDrag = (e) => {
    if (isDraggingAbs) {
      isDraggingAbs = false;
      updateCrosshair(e);
    }
  };
  absCanvas?.addEventListener("pointerup", endAbsDrag);
  absCanvas?.addEventListener("pointercancel", endAbsDrag);

  async function sendAbsMove(action = "none", button = "") {
    try {
      setText("mouse-status", "Moving absolute...");
      const res = await api("/api/mouse_move_abs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          x: absCoords.x,
          y: absCoords.y,
          button: button,
          action: action,
        }),
      });
      if (!res.ok) throw new Error();
      setText("mouse-status", `Moved to (${absCoords.x}%, ${absCoords.y}%)${button ? " and clicked " + button : ""}.`);
    } catch (_) {
      setText("mouse-status", "Absolute mouse command failed.");
    }
  }

  qs("abs-move-btn")?.addEventListener("click", () => sendAbsMove("none", ""));
  qs("abs-click-btn")?.addEventListener("click", () => sendAbsMove("click", "left"));
  qs("abs-rclick-btn")?.addEventListener("click", () => sendAbsMove("click", "right"));
}

let selectedOtaFile = null;

function bindOtaControls() {
  const dropzone = qs("ota-dropzone");
  const fileInput = qs("ota-file-input");
  const browseBtn = qs("ota-browse-btn");
  const flashBtn = qs("ota-flash-btn");
  const prompt = qs("ota-dropzone-prompt");
  const fileInfo = qs("ota-file-info");
  const filenameSpan = qs("ota-filename");
  const filesizeSpan = qs("ota-filesize");
  const progressBox = qs("ota-progress-box");
  const progressBar = qs("ota-progress-bar");
  const progressText = qs("ota-progress-text");
  const speedText = qs("ota-speed-text");
  const statusSpan = qs("ota-status");
  const modeBadge = qs("ota-mode-badge");

  if (!dropzone || !fileInput || !flashBtn) return;

  const updateTypeBadge = () => {
    const type = document.querySelector('input[name="ota-type"]:checked')?.value || "firmware";
    if (modeBadge) modeBadge.textContent = (type === "littlefs") ? "Filesystem" : "Firmware";
  };

  document.querySelectorAll('input[name="ota-type"]').forEach((radio) => {
    radio.addEventListener("change", updateTypeBadge);
  });

  const selectFile = (file) => {
    if (!file) return;
    if (!file.name.endsWith(".bin")) {
      if (statusSpan) statusSpan.textContent = "Please select a valid .bin file.";
      return;
    }
    selectedOtaFile = file;
    if (filenameSpan) filenameSpan.textContent = file.name;
    if (filesizeSpan) filesizeSpan.textContent = `(${(file.size / 1024).toFixed(1)} KB)`;
    if (prompt) prompt.classList.add("hidden");
    if (fileInfo) fileInfo.classList.remove("hidden");
    flashBtn.disabled = false;
    if (statusSpan) statusSpan.textContent = "Ready to flash.";

    if (file.name.toLowerCase().includes("littlefs") || file.name.toLowerCase().includes("spiffs")) {
      const fsRadio = document.querySelector('input[name="ota-type"][value="littlefs"]');
      if (fsRadio) { fsRadio.checked = true; updateTypeBadge(); }
    } else if (file.name.toLowerCase().includes("firmware")) {
      const fwRadio = document.querySelector('input[name="ota-type"][value="firmware"]');
      if (fwRadio) { fwRadio.checked = true; updateTypeBadge(); }
    }

    // Client-side Binary Inspector (Reads ESP32 image header & esp_app_desc_t before flashing)
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const buffer = evt.target.result;
        const bytes = new Uint8Array(buffer);
        let detectedInfo = "";

        if (bytes[0] === 0xE9) { // ESP32 magic byte
          const chipId = bytes[12] | (bytes[13] << 8);
          let chipName = "ESP32-S3";
          if (chipId === 0x0000) chipName = "ESP32 (Generic)";
          else if (chipId === 0x0005) chipName = "ESP32-C3";

          let versionFound = null;
          let buildDateFound = null;
          // Search for esp_app_desc_t magic number (0xABCD5432)
          for (let i = 0; i < bytes.length - 64; i++) {
            if (bytes[i] === 0x32 && bytes[i+1] === 0x54 && bytes[i+2] === 0xCD && bytes[i+3] === 0xAB) {
              const verBytes = bytes.slice(i + 16, i + 48);
              versionFound = new TextDecoder().decode(verBytes).replace(/\0.*$/g, '').trim();
              const dateBytes = bytes.slice(i + 96, i + 112);
              const timeBytes = bytes.slice(i + 80, i + 96);
              const dStr = new TextDecoder().decode(dateBytes).replace(/\0.*$/g, '').trim();
              const tStr = new TextDecoder().decode(timeBytes).replace(/\0.*$/g, '').trim();
              if (dStr) buildDateFound = `${dStr} ${tStr}`.trim();
              break;
            }
          }

          if (versionFound) {
            detectedInfo = `✅ Verified ${chipName} Firmware: v${versionFound}${buildDateFound ? ' (' + buildDateFound + ')' : ''}`;
          } else {
            detectedInfo = `✅ Verified ${chipName} Binary Image`;
          }

          const fwRadio = document.querySelector('input[name="ota-type"][value="firmware"]');
          if (fwRadio) { fwRadio.checked = true; updateTypeBadge(); }
        } else if (file.name.toLowerCase().includes("littlefs") || file.size > 8 * 1024 * 1024) {
          detectedInfo = `📁 Filesystem Image (${(file.size / 1024 / 1024).toFixed(2)} MB LittleFS Image)`;
          const fsRadio = document.querySelector('input[name="ota-type"][value="littlefs"]');
          if (fsRadio) { fsRadio.checked = true; updateTypeBadge(); }
        }

        if (statusSpan && detectedInfo) {
          statusSpan.innerHTML = `<strong>${detectedInfo}</strong>`;
        }
      } catch (_) {}
    };
    reader.readAsArrayBuffer(file.slice(0, 1024));
  };

  browseBtn?.addEventListener("click", (e) => {
    e.stopPropagation();
    fileInput.click();
  });
  dropzone.addEventListener("click", () => fileInput.click());

  fileInput.addEventListener("change", (e) => {
    if (e.target.files && e.target.files[0]) {
      selectFile(e.target.files[0]);
    }
  });

  dropzone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropzone.classList.add("drag-over");
  });
  dropzone.addEventListener("dragleave", () => {
    dropzone.classList.remove("drag-over");
  });
  dropzone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropzone.classList.remove("drag-over");
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      selectFile(e.dataTransfer.files[0]);
    }
  });

  flashBtn.addEventListener("click", () => {
    if (!selectedOtaFile) return;

    const isFs = (document.querySelector('input[name="ota-type"]:checked')?.value === "littlefs");
    const targetUrl = isFs ? "/api/ota?type=littlefs" : "/api/ota";

    flashBtn.disabled = true;
    if (progressBox) progressBox.classList.remove("hidden");
    if (progressBar) progressBar.style.width = "0%";
    if (statusSpan) statusSpan.textContent = "Uploading update to ESP32-S3...";

    const startTime = Date.now();
    const xhr = new XMLHttpRequest();
    xhr.open("POST", targetUrl, true);

    let uploadPercent = 0;
    let uploadFinished = false;

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        uploadPercent = Math.round((e.loaded / e.total) * 100);
        if (progressBar) progressBar.style.width = uploadPercent + "%";
        const elapsedSec = Math.max((Date.now() - startTime) / 1000, 0.1);
        const speedKB = Math.round((e.loaded / 1024) / elapsedSec);
        if (progressText) progressText.textContent = `Flashing: ${uploadPercent}% (${(e.loaded / 1024).toFixed(0)} / ${(e.total / 1024).toFixed(0)} KB)`;
        if (speedText) speedText.textContent = `${speedKB} KB/s`;
      }
    };

    const startReconnectRoutine = () => {
      if (uploadFinished) return;
      uploadFinished = true;

      if (progressBar) progressBar.style.width = "100%";
      if (progressText) progressText.textContent = "Flash Complete! Rebooting...";
      if (statusSpan) statusSpan.textContent = "Device is rebooting. Waiting for reconnection...";

      let attempts = 0;
      const maxAttempts = 20;

      // Wait 3 seconds for reboot, then actively poll every 1.5s
      setTimeout(() => {
        const pingInterval = setInterval(async () => {
          attempts++;
          if (statusSpan) statusSpan.textContent = `Reconnecting to ESP32-S3 (attempt ${attempts}/${maxAttempts})...`;

          try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 1200);
            const res = await fetch("/api/login_status?t=" + Date.now(), { signal: controller.signal });
            clearTimeout(timeoutId);

            if (res.ok || res.status === 401 || res.status === 403) {
              clearInterval(pingInterval);
              if (statusSpan) statusSpan.textContent = "✅ Reconnected! Refreshing application...";
              setTimeout(() => {
                window.location.replace("/login?v=" + Date.now());
              }, 600);
              return;
            }
          } catch (_) {}

          if (attempts >= maxAttempts) {
            clearInterval(pingInterval);
            if (statusSpan) statusSpan.textContent = "Reboot finished. Redirecting...";
            window.location.replace("/login?v=" + Date.now());
          }
        }, 1500);
      }, 3000);
    };

    xhr.onload = () => {
      if (xhr.status === 200) {
        startReconnectRoutine();
      } else {
        flashBtn.disabled = false;
        if (statusSpan) statusSpan.textContent = "OTA Update failed. Check binary size and format.";
      }
    };

    xhr.onerror = () => {
      if (uploadPercent >= 99) {
        startReconnectRoutine();
      } else {
        flashBtn.disabled = false;
        if (statusSpan) statusSpan.textContent = "Network error during OTA upload.";
      }
    };

    const formData = new FormData();
    formData.append("file", selectedOtaFile, selectedOtaFile.name);
    xhr.send(formData);
  });
}

function updateSliderReadout(id, unit = "") {
  const input = qs(id);
  const out = qs(`${id}-value`);
  if (!input || !out) return;
  out.textContent = `${input.value}${unit}`;
}

function bindSliderReadout(id, unit = "") {
  const input = qs(id);
  if (!input) return;

  input.addEventListener("input", () => updateSliderReadout(id, unit));
  updateSliderReadout(id, unit);
}

function bindHelpPanel() {
  const panel = qs("help-panel");
  const title = qs("help-title");
  const body = qs("help-body");
  const best = qs("help-best");

  document.querySelectorAll(".help-icon").forEach((icon) => {
    icon.addEventListener("click", () => {
      const key = icon.dataset.helpKey;
      const info = tuningHelp[key];
      if (!info) return;

      title.textContent = info.title;
      body.textContent = info.body;
      best.textContent = info.best;
      panel.classList.remove("hidden");
    });
  });

  qs("help-close").addEventListener("click", () => panel.classList.add("hidden"));
}

function generateRandomToken(hexChars = 48) {
  const byteCount = Math.max(8, Math.floor(hexChars / 2));
  const bytes = new Uint8Array(byteCount);

  if (window.crypto && window.crypto.getRandomValues) {
    window.crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < byteCount; i++) {
      bytes[i] = Math.floor(Math.random() * 256);
    }
  }

  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function applyVendorPreset(presetKey) {
  if (presetKey === "custom") return;

  const preset = usbVendorPresets[presetKey];
  if (!preset) return;

  qs("usb-vendor-name").value = preset.vendorName;
  qs("usb-vendor-id").value = formatHex16(preset.vid);
  qs("usb-product-id").value = formatHex16(preset.pid);
  qs("usb-product-name").value = preset.productName;
}

function updateVendorPresetSelectionFromFields() {
  const vid = parseHexOrDecStrict(qs("usb-vendor-id").value);
  const vendorName = qs("usb-vendor-name").value.trim().toLowerCase();
  const productId = parseHexOrDecStrict(qs("usb-product-id").value);

  let matched = "custom";
  Object.entries(usbVendorPresets).forEach(([key, preset]) => {
    if (
      matched === "custom"
      && preset.vid === vid
      && preset.vendorName.toLowerCase() === vendorName
      && preset.pid === productId
    ) {
      matched = key;
    }
  });

  qs("usb-vendor-preset").value = matched;
}

function shellQuote(value) {
  const escaped = String(value || "").replace(/"/g, '\\"');
  return `"${escaped}"`;
}

function buildHostCommand(deviceIp, port, options = {}) {
  const host = deviceIp || "192.168.4.1";
  const exclusive = Boolean(options.blockLocalInput);
  const preview = Boolean(options.preview);

  const base = [
    "python",
    "esp32_kvm.py",
    "--ip", shellQuote(host),
    "--port", String(port || 4210),
    "--toggle", "f8",
  ];

  if (exclusive) {
    base.push("--exclusive");
  }
  if (preview) {
    base.push("--preview");
  }

  return base.join(" ");
}

function updateKvmHelperPanel(statusData = {}) {
  const ip = statusData.device_ip || "192.168.4.1";
  const port = Number(statusData.port || qs("kvm-port")?.value || 4210);

  const cmdMain = buildHostCommand(ip, port, {
    preview: false,
    blockLocalInput: false,
  });
  const cmdExclusive = buildHostCommand(ip, port, {
    preview: false,
    blockLocalInput: true,
  });
  const targetCaptureCommand = "python esp32_kvm.py --preview --preview-port 8080";

  const mainEl = qs("kvm-cmd-main");
  const lowEl = qs("kvm-cmd-no-preview");
  const targetCaptureEl = qs("target-capture-cmd");
  if (mainEl) mainEl.value = cmdMain;
  if (lowEl) lowEl.value = cmdExclusive;
  if (targetCaptureEl) targetCaptureEl.value = targetCaptureCommand;

  const screenshotUrlInput = qs("screenshot-url");
  if (screenshotUrlInput && (!screenshotUrlInput.value.trim() || screenshotUrlInput.value.includes("9988"))) {
    screenshotUrlInput.value = "http://192.168.1.55:8080/screenshot.jpg";
  }
}

function updateKvmLinkIndicator(statusData = {}) {
  const dot = qs("kvm-link-dot");
  const stateEl = qs("kvm-link-state");
  const ageEl = qs("kvm-link-age");
  if (!dot || !stateEl || !ageEl) return;

  dot.classList.remove("connected", "warning", "offline");

  const linkState = String(statusData.link_state || "unknown");
  const age = Number(statusData.packet_age_ms);
  const hasAge = Number.isFinite(age) && age >= 0 && age < 0xFFFFFF00;

  let label = "Status: unknown";
  if (linkState === "connected") {
    dot.classList.add("connected");
    label = "Status: connected";
  } else if (linkState === "bind-failed") {
    dot.classList.add("offline");
    label = "Status: bind failed";
  } else if (linkState === "waiting" || linkState === "stale") {
    dot.classList.add("warning");
    label = linkState === "waiting" ? "Status: waiting for packets" : "Status: stale";
  } else if (linkState === "disabled") {
    label = "Status: disabled";
  } else {
    dot.classList.add("offline");
    label = "Status: offline";
  }

  stateEl.textContent = label;
  ageEl.textContent = hasAge ? `Last packet age: ${age} ms` : "Last packet age: -";
}

function sanitizeActionFilename(name) {
  const cleaned = String(name || "").trim();
  if (!/^[a-zA-Z0-9_.\- ]{1,64}$/.test(cleaned)) return "";
  return cleaned;
}

function getRecordSource() {
  const raw = qs("record-source")?.value;
  return raw === "kvm_bridge" ? "kvm_bridge" : "ui";
}

function modifierCodesFromMask(mask) {
  const codeSet = new Set();
  bridgeModifierMap.forEach((entry) => {
    if (mask & entry.bit) {
      codeSet.add(entry.code);
    }
  });
  return Array.from(codeSet);
}

function normalizedBridgeKeySet(keys) {
  const out = new Set();
  if (!Array.isArray(keys)) return out;

  keys.forEach((key) => {
    const code = Math.trunc(clampNumber(key, 0, 255));
    if (code > 0) out.add(code);
  });

  return out;
}

function convertBridgeEventsToRecorderEvents(bridgeEvents = []) {
  const out = [];
  let previousDt = 0;
  let previousButtons = 0;
  let previousModifiers = 0;
  let previousKeys = new Set();

  bridgeEvents.forEach((rawEvent) => {
    const event = rawEvent && typeof rawEvent === "object" ? rawEvent : {};
    const dt = Math.trunc(clampNumber(event.dt, 0, 3_600_000));
    const baseDelay = Math.max(0, dt - previousDt);
    previousDt = dt;

    let firstAction = true;
    const pushAction = (action) => {
      out.push({
        delay: firstAction ? baseDelay : 0,
        ...action,
      });
      firstAction = false;
    };

    if (event.type === "mouse") {
      const dx = Math.trunc(clampNumber(event.dx, -4096, 4096));
      const dy = Math.trunc(clampNumber(event.dy, -4096, 4096));
      const wheel = Math.trunc(clampNumber(event.wheel, -127, 127));
      const pan = Math.trunc(clampNumber(event.pan, -127, 127));
      const buttons = Math.trunc(clampNumber(event.buttons, 0, 31));

      if (dx !== 0 || dy !== 0) {
        pushAction({ type: "mouse_move", dx, dy });
      }
      if (wheel !== 0 || pan !== 0) {
        pushAction({ type: "mouse_scroll", wheel, pan });
      }

      const changed = previousButtons ^ buttons;
      bridgeMouseButtonMasks.forEach((mask) => {
        if ((changed & mask) === 0) return;
        const action = (buttons & mask) ? 1 : 2;
        pushAction({ type: "mouse_button", button: mask, action });
      });

      previousButtons = buttons;
      return;
    }

    if (event.type === "keyboard") {
      const modifierMask = Math.trunc(clampNumber(event.modifiers, 0, 255));
      const currentModifierCodes = modifierCodesFromMask(modifierMask);
      const previousModifierCodes = modifierCodesFromMask(previousModifiers);

      previousModifierCodes.forEach((code) => {
        if (!currentModifierCodes.includes(code)) {
          pushAction({ type: "key_up", code });
        }
      });

      const currentKeys = normalizedBridgeKeySet(event.keys);
      previousKeys.forEach((code) => {
        if (!currentKeys.has(code)) {
          pushAction({ type: "key_up", code });
        }
      });

      currentModifierCodes.forEach((code) => {
        if (!previousModifierCodes.includes(code)) {
          pushAction({ type: "key_down", code });
        }
      });

      currentKeys.forEach((code) => {
        if (!previousKeys.has(code)) {
          pushAction({ type: "key_down", code });
        }
      });

      previousModifiers = modifierMask;
      previousKeys = currentKeys;
      return;
    }

    if (event.type === "consumer") {
      const usage = Math.trunc(clampNumber(event.usage, 0, 0xFFFF));
      pushAction({ type: "consumer", usage });
    }
  });

  if (previousButtons !== 0 || previousKeys.size > 0 || previousModifiers !== 0) {
    out.push({ delay: 0, type: "key_release_all" });
    bridgeMouseButtonMasks.forEach((mask) => {
      if (previousButtons & mask) {
        out.push({ delay: 0, type: "mouse_button", button: mask, action: 2 });
      }
    });
  }

  return out;
}

async function loadBridgeRecordStatus() {
  const el = qs("record-bridge-status");
  if (!el) return;

  try {
    const res = await api("/api/kvm_bridge_record_status");
    if (!res.ok) {
      el.textContent = "Bridge recorder status unavailable.";
      return;
    }

    const data = await res.json();
    const enabled = Boolean(data.enabled);
    const count = Math.trunc(clampNumber(data.count, 0, 1_000_000));
    const dropped = Math.trunc(clampNumber(data.dropped, 0, 1_000_000));
    const duration = Math.trunc(clampNumber(data.duration_ms, 0, 86_400_000));

    if (enabled) {
      el.textContent = `Bridge recording active: ${count} events (${dropped} dropped, ${duration} ms).`;
    } else {
      el.textContent = `Bridge recorder ready: ${count} events buffered (${dropped} dropped).`;
    }
  } catch (_) {
    el.textContent = "Bridge recorder status unavailable.";
  }
}

function encodeKrecBinary(events) {
  const buffer = new ArrayBuffer(8 + events.length * 8);
  const view = new DataView(buffer);

  // Magic 'KREC' (0x4B, 0x52, 0x45, 0x43)
  view.setUint8(0, 0x4B);
  view.setUint8(1, 0x52);
  view.setUint8(2, 0x45);
  view.setUint8(3, 0x43);
  view.setUint16(4, 1, true); // version 1 (little-endian)
  view.setUint16(6, 0, true); // reserved 0

  let offset = 8;
  const TYPE_MAP = {
    key_down: 1,
    key_up: 2,
    key_tap: 3,
    key_release_all: 4,
    combo: 5,
    mouse_move: 6,
    mouse_abs: 7,
    mouse_scroll: 8,
    mouse_button: 9,
    consumer: 10,
  };

  events.forEach((ev) => {
    const delay = Math.trunc(clampNumber(ev.delay, 0, 65535));
    const type = TYPE_MAP[ev.type] || 0;
    let flags = 0;
    let p1 = 0;
    let p2 = 0;

    if (ev.type === "key_down" || ev.type === "key_up") {
      p1 = Math.trunc(clampNumber(ev.code, 0, 255));
    } else if (ev.type === "key_tap") {
      p1 = Math.trunc(clampNumber(ev.code, 0, 255));
      p2 = Math.trunc(clampNumber(ev.hold, 10, 300));
    } else if (ev.type === "combo") {
      flags = Math.trunc(clampNumber(ev.flags, 0, 15));
      p1 = Math.trunc(clampNumber(ev.code, 0, 255));
      p2 = Math.trunc(clampNumber(ev.hold, 10, 300));
    } else if (ev.type === "mouse_move") {
      p1 = Math.trunc(clampNumber(ev.dx, -4096, 4096));
      p2 = Math.trunc(clampNumber(ev.dy, -4096, 4096));
    } else if (ev.type === "mouse_abs") {
      p1 = Math.trunc(clampNumber(ev.x, 0, 32767));
      p2 = Math.trunc(clampNumber(ev.y, 0, 32767));
    } else if (ev.type === "mouse_scroll") {
      p1 = Math.trunc(clampNumber(ev.wheel, -127, 127));
      p2 = Math.trunc(clampNumber(ev.pan, -127, 127));
    } else if (ev.type === "mouse_button") {
      flags = Math.trunc(clampNumber(ev.button, 1, 31));
      p1 = Math.trunc(clampNumber(ev.action, 0, 2));
    } else if (ev.type === "consumer") {
      p1 = Math.trunc(clampNumber(ev.usage, 0, 0xFFFF));
    }

    view.setUint16(offset + 0, delay, true);
    view.setUint8(offset + 2, type);
    view.setUint8(offset + 3, flags);
    view.setInt16(offset + 4, p1, true);
    view.setInt16(offset + 6, p2, true);
    offset += 8;
  });

  return buffer;
}

async function startRecording() {
  const source = getRecordSource();
  recorder.source = source;
  recorder.lastEventAt = 0;
  recorder.events = [];
  recorder.active = false;
  recorder.bridgeActive = false;

  if (source === "ui") {
    recorder.active = true;
    setText("record-status", "UI recording started. Use Remote/Keyboard/Mouse controls now.");
    return;
  }

  try {
    const res = await api("/api/kvm_bridge_record_start", { method: "POST" });
    if (!res.ok) {
      setText("record-status", "Failed to start KVM bridge recording.");
      return;
    }

    recorder.bridgeActive = true;
    setText("record-status", "Bridge recording started. Generate traffic from host sender now.");
    await loadBridgeRecordStatus();
  } catch (_) {
    setText("record-status", "Network error while starting bridge recording.");
  }
}

async function stopRecording() {
  if (recorder.source !== "kvm_bridge") {
    recorder.active = false;
    if (recorder.events.length > 0) {
      setText("record-status", `Recording stopped. ${recorder.events.length} events captured.`);
    } else {
      setText("record-status", "Recording stopped with 0 events. Trigger UI input while recording.");
    }
    return;
  }

  if (!recorder.bridgeActive) {
    setText("record-status", "Bridge recorder is not running.");
    return;
  }

  try {
    const stopRes = await api("/api/kvm_bridge_record_stop", { method: "POST" });
    if (!stopRes.ok) {
      setText("record-status", "Failed to stop bridge recorder.");
      return;
    }

    const exportRes = await api("/api/kvm_bridge_record_export");
    if (!exportRes.ok) {
      setText("record-status", "Bridge recorder stopped, but export failed.");
      recorder.bridgeActive = false;
      return;
    }

    const data = await exportRes.json();
    const bridgeEvents = Array.isArray(data.events) ? data.events : [];
    recorder.events = convertBridgeEventsToRecorderEvents(bridgeEvents);
    recorder.bridgeActive = false;
    recorder.active = false;
    recorder.lastEventAt = 0;

    const dropped = Math.trunc(clampNumber(data.dropped, 0, 1_000_000));
    setText(
      "record-status",
      `Bridge recording imported: ${recorder.events.length} replay events (${bridgeEvents.length} raw packets, ${dropped} dropped).`,
    );
    await loadBridgeRecordStatus();
  } catch (_) {
    setText("record-status", "Network error while stopping bridge recorder.");
  }
}

async function clearRecording() {
  recorder.active = false;
  recorder.lastEventAt = 0;
  recorder.events = [];

  const shouldClearBridge = getRecordSource() === "kvm_bridge" || recorder.source === "kvm_bridge";
  recorder.bridgeActive = false;

  if (shouldClearBridge) {
    try {
      await api("/api/kvm_bridge_record_stop", { method: "POST" });
      await api("/api/kvm_bridge_record_clear", { method: "POST" });
      await loadBridgeRecordStatus();
    } catch (_) {
      setText("record-status", "Local recorder cleared, but bridge clear failed.");
      return;
    }
  }

  setText("record-status", "Recorder cleared.");
}

async function saveRecordingToDevice() {
  if (recorder.bridgeActive) {
    setText("record-status", "Stop bridge recording before saving.");
    return;
  }

  if (!recorder.events.length) {
    setText("record-status", "Nothing to save. Record actions first.");
    return;
  }

  let entered = qs("record-file-name").value.trim() || `action-${Date.now()}.krec`;
  if (!entered.toLowerCase().endsWith(".krec")) {
    entered += ".krec";
  }
  const safeName = sanitizeActionFilename(entered);
  if (!safeName) {
    setText("record-status", "Invalid file name. Allowed: letters, numbers, space, _, -, .");
    return;
  }

  const binaryData = encodeKrecBinary(recorder.events);
  try {
    const res = await api(`/api/action_file/save?name=${encodeURIComponent(safeName)}`, {
      method: "POST",
      headers: { "Content-Type": "application/octet-stream" },
      body: binaryData,
    });

    if (!res.ok) {
      setText("record-status", "Failed to save recording to ESP.");
      return;
    }

    qs("record-file-name").value = safeName;
    await loadActionFiles();
    setText("record-status", `Saved to ESP as ${safeName} (${binaryData.byteLength} bytes).`);
  } catch (_) {
    setText("record-status", "Network error while saving recording.");
  }
}

function downloadRecordingFile() {
  if (recorder.bridgeActive) {
    setText("record-status", "Stop bridge recording before downloading.");
    return;
  }

  if (!recorder.events.length) {
    setText("record-status", "No recording available.");
    return;
  }

  let entered = qs("record-file-name").value.trim() || `action-${Date.now()}.krec`;
  if (!entered.toLowerCase().endsWith(".krec")) {
    entered += ".krec";
  }
  const safeName = sanitizeActionFilename(entered) || `action-${Date.now()}.krec`;
  const binaryData = encodeKrecBinary(recorder.events);
  const blob = new Blob([binaryData], { type: "application/octet-stream" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = safeName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(a.href);
  setText("record-status", `Recording downloaded as ${safeName}.`);
}

function selectedActionFileName() {
  const select = qs("action-files-select");
  if (!select || !select.value) return "";
  return sanitizeActionFilename(select.value);
}

async function loadActionFiles() {
  const select = qs("action-files-select");
  if (!select) return;

  try {
    const res = await api("/api/action_files");
    if (!res.ok) {
      setText("record-status", "Failed to list action files.");
      return;
    }

    const files = await res.json();
    select.innerHTML = "";

    if (!Array.isArray(files) || files.length === 0) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "No action files";
      select.appendChild(option);
      return;
    }

    files
      .sort((a, b) => a.name.localeCompare(b.name))
      .forEach((file) => {
        const option = document.createElement("option");
        option.value = file.name;
        option.textContent = `${file.name} (${file.size} bytes)`;
        select.appendChild(option);
      });
  } catch (_) {
    setText("record-status", "Network error while listing action files.");
  }
}

async function runSelectedActionFile() {
  const name = selectedActionFileName();
  if (!name) {
    setText("record-status", "Select an action file first.");
    return;
  }

  setText("record-status", `Queuing: ${name}...`);
  try {
    const res = await api(`/api/action_file/run?name=${encodeURIComponent(name)}`, { method: "POST" });
    if (!res.ok) {
      let errDetail = "";
      try {
        const errJson = await res.json();
        errDetail = errJson.error ? ` (${errJson.error})` : "";
      } catch (_) {}
      const msg = {
        400: `Bad file name: "${name}"`,
        404: `File not found on ESP: "${name}" — re-upload it`,
        503: "ESP is busy running another script — wait and retry",
      }[res.status] || `HTTP ${res.status}${errDetail}`;
      setText("record-status", `❌ ${msg}`);
      return;
    }

    setText("record-status", `✅ Queued: ${name} — running on ESP32...`);
    refreshStatus();
  } catch (_) {
    setText("record-status", "Network error while queueing action file.");
  }
}

async function deleteSelectedActionFile() {
  const name = selectedActionFileName();
  if (!name) {
    setText("record-status", "Select an action file first.");
    return;
  }

  if (!confirm(`Delete action file ${name}?`)) return;

  try {
    const res = await api(`/api/action_file/delete?name=${encodeURIComponent(name)}`, {
      method: "DELETE",
    });
    if (!res.ok) {
      setText("record-status", "Failed to delete action file.");
      return;
    }

    await loadActionFiles();
    setText("record-status", "Action file deleted.");
  } catch (_) {
    setText("record-status", "Network error while deleting action file.");
  }
}

async function importActionFileToDevice(file) {
  let entered = file?.name || `imported-action-${Date.now()}.krec`;
  if (!entered.toLowerCase().endsWith(".krec")) {
    entered += ".krec";
  }
  const safeName = sanitizeActionFilename(entered);
  if (!safeName) {
    setText("record-status", "Invalid imported file name.");
    return;
  }

  const arrayBuffer = await file.arrayBuffer();
  if (!arrayBuffer || arrayBuffer.byteLength < 8) {
    setText("record-status", "Imported file is empty or invalid.");
    return;
  }

  try {
    const res = await api(`/api/action_file/save?name=${encodeURIComponent(safeName)}`, {
      method: "POST",
      headers: { "Content-Type": "application/octet-stream" },
      body: arrayBuffer,
    });

    if (!res.ok) {
      setText("record-status", "Failed to import file to ESP.");
      return;
    }

    qs("record-file-name").value = safeName;
    await loadActionFiles();
    setText("record-status", `Imported and saved as ${safeName} (${arrayBuffer.byteLength} bytes).`);
  } catch (_) {
    setText("record-status", "Network error while importing action file.");
  }
}

async function loadKvmStatus() {
  try {
    const res = await api("/api/kvm_status");
    if (!res.ok) {
      setText("kvm-status", "Failed to load KVM status.");
      return;
    }

    const d = await res.json();

    const elEnabled = qs("kvm-enabled");
    const elPort = qs("kvm-port");
    const elIp = qs("kvm-allowed-ip");

    if (document.activeElement !== elEnabled) elEnabled.checked = Boolean(d.enabled);
    if (document.activeElement !== elPort) elPort.value = d.port ?? 4210;
    if (document.activeElement !== elIp) elIp.value = d.allowed_ip || "";

    setText("kvm-packets-rx", String(d.packets_rx ?? 0));
    setText("kvm-packets-dropped", String(d.packets_dropped ?? 0));
    setText("kvm-last-seq", d.last_sequence != null ? String(d.last_sequence) : "-");
    setText("kvm-last-source", d.last_source_ip || "-");
    updateKvmLinkIndicator(d);
    updateKvmHelperPanel(d);
    loadBridgeRecordStatus();

    const listening = d.enabled && d.bound;
    const ip = d.device_ip || "ESP32 IP";
    const configuredPort = Number(d.port || 4210);
    const boundPort = Number(d.bound_port || 0);
    const effectivePort = boundPort > 0 ? boundPort : configuredPort;
    if (d.connected) {
      const age = Number.isFinite(Number(d.packet_age_ms)) ? `, age ${d.packet_age_ms} ms` : "";
      setText("kvm-status", `Connected on UDP ${effectivePort} (${ip}${age})`);
    } else if (listening) {
      setText("kvm-status", `Listening on UDP ${effectivePort} (${ip}), waiting packets`);
    } else if (d.enabled && String(d.bind_error || "").length > 0) {
      setText("kvm-status", `KVM enabled but bind failed on UDP ${configuredPort} (${d.bind_error}).`);
    } else if (d.enabled) {
      setText("kvm-status", `KVM enabled but UDP ${configuredPort} not bound yet.`);
    } else {
      setText("kvm-status", "KVM listener disabled.");
    }
  } catch (_) {
    setText("kvm-status", "Network error while loading KVM status.");
  }
}

function getScreenshotRefreshIntervalMs() {
  return Math.trunc(clampNumber(qs("screenshot-interval-ms")?.value || 2000, 500, 10000));
}

function cleanupScreenshotObjectUrl() {
  if (screenshotObjectUrl) {
    URL.revokeObjectURL(screenshotObjectUrl);
    screenshotObjectUrl = "";
  }
}

async function loadScreenshotPreview() {
  const img = qs("screenshot-image");
  const urlInput = qs("screenshot-url");
  if (!img || !urlInput) return;

  const baseUrl = urlInput.value.trim();
  if (!baseUrl) {
    setText("screenshot-status", "Enter target screenshot URL first.");
    return;
  }

  const fetchUrl = baseUrl.includes("?") ? `${baseUrl}&_t=${Date.now()}` : `${baseUrl}?_t=${Date.now()}`;
  setText("screenshot-status", "Loading target screenshot...");

  try {
    const res = await fetch(fetchUrl, { cache: "no-store" });
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }

    const blob = await res.blob();
    if (!blob || blob.size < 32) {
      throw new Error("empty-image");
    }

    cleanupScreenshotObjectUrl();
    screenshotObjectUrl = URL.createObjectURL(blob);
    img.src = screenshotObjectUrl;
    img.classList.add("visible");
    setText("screenshot-status", `Target screenshot updated (${blob.size} bytes).`);
  } catch (err) {
    setText("screenshot-status", `Target screenshot load failed: ${String(err?.message || err)}`);
  }
}

function stopScreenshotAutoRefresh() {
  if (screenshotRefreshTimer) {
    clearInterval(screenshotRefreshTimer);
    screenshotRefreshTimer = null;
  }
}

function syncScreenshotAutoRefresh() {
  const enabled = Boolean(qs("screenshot-auto-refresh")?.checked);
  stopScreenshotAutoRefresh();

  if (!enabled) return;

  const interval = getScreenshotRefreshIntervalMs();
  screenshotRefreshTimer = setInterval(() => {
    if (activeTab === "kvm") {
      loadScreenshotPreview();
    }
  }, interval);
}

async function saveKvmConfig() {
  const port = Math.trunc(clampNumber(qs("kvm-port").value, 1, 65535));
  qs("kvm-port").value = String(port);
  const payload = {
    enabled: qs("kvm-enabled").checked,
    port,
    allowed_ip: qs("kvm-allowed-ip").value.trim(),
  };

  try {
    const res = await api("/api/kvm_config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      setText("kvm-status", "Failed to apply KVM config.");
      return;
    }

    let bindMessage = "KVM config saved.";
    try {
      const info = await res.json();
      if (payload.enabled && !info.bound) {
        const err = String(info.bind_error || "not-bound");
        bindMessage = `KVM saved, but UDP bind failed (${err}).`;
      } else if (payload.enabled && info.bound) {
        const effectivePort = Math.trunc(clampNumber(info.bound_port || port, 1, 65535));
        bindMessage = `KVM config saved and listening on UDP ${effectivePort}.`;
      }
    } catch (_) {}

    setText("kvm-status", bindMessage);
    await loadKvmStatus();
  } catch (_) {
    setText("kvm-status", "Network error while saving KVM config.");
  }
}

async function releaseAllHid() {
  try {
    const res = await api("/api/hid_release_all", { method: "POST" });
    if (!res.ok) {
      setText("kvm-status", "Failed to release HID state.");
      return;
    }

    lockedModifiers.clear();
    pointerPressedKeys.clear();
    document.querySelectorAll(".mod-lock").forEach((btn) => btn.classList.remove("active"));
    document.querySelectorAll(".vk-key.active").forEach((btn) => btn.classList.remove("active"));
    leftMouseHeld = false;
    qs("mouse-left-hold-btn").textContent = "Hold Left";
    setText("kvm-status", "All HID keys/buttons released.");
  } catch (_) {
    setText("kvm-status", "Network error while releasing HID state.");
  }
}

async function loadSettings() {
  try {
    const res = await api("/api/get_settings");
    if (!res.ok) {
      setText("settings-status", "Failed to load settings.");
      return;
    }

    const d = await res.json();
    updateNetworkInfo(d);
    qs("ap-ssid").value = d.ap_ssid || "";
    qs("ap-pass").value = d.ap_pass || "";
    qs("sta-ssid").value = d.sta_ssid || "";
    qs("sta-pass").value = d.sta_pass || "";
    qs("admin-user").value = d.admin_user || "admin";

    qs("typing-delay").value = d.delay ?? 6;
    qs("burst-chars").value = d.burst_chars ?? 24;
    qs("burst-pause").value = d.burst_pause ?? 10;
    qs("line-delay").value = d.line_delay ?? 40;
    qs("kvm-mouse-smooth").value = d.kvm_mouse_smooth ?? 100;
    qs("led-bright").value = d.bright ?? 50;

    qs("login-rate-limit").checked = d.login_rate_limit ?? true;
    qs("proxy-auth-enabled").checked = d.proxy_auth_enabled ?? false;
    qs("proxy-auth-token").value = d.proxy_auth_token || "";

    qs("usb-vendor-name").value = d.usb_vendor_name || "Espressif";
    qs("usb-product-name").value = d.usb_product_name || "ESP32-S3 HID Console";
    qs("usb-vendor-id").value = formatHex16(d.usb_vid ?? 0x303A);
    qs("usb-product-id").value = formatHex16(d.usb_pid ?? 0x0002);

    const mscCheck = qs("usb-msc-enabled");
    const mscBadge = qs("usb-msc-status-badge");
    if (mscCheck) {
      mscCheck.checked = d.usb_msc_enabled ?? true;
      if (mscBadge) {
        mscBadge.textContent = mscCheck.checked ? "Enabled" : "Disabled";
        mscBadge.className = mscCheck.checked ? "badge ok" : "badge";
      }
    }
    if (qs("usb-msc-label")) qs("usb-msc-label").value = d.usb_msc_label || "DUCKY_DRIVE";
    if (qs("usb-msc-backend")) qs("usb-msc-backend").value = String(d.usb_msc_backend ?? 0);
    if (qs("usb-msc-autosave")) qs("usb-msc-autosave").checked = d.usb_msc_autosave ?? false;

    const bleFidoCheck = qs("ble-fido-enabled");
    const bleFidoBadge = qs("ble-fido-status-badge");
    if (bleFidoCheck) {
      bleFidoCheck.checked = d.ble_fido_enabled ?? false;
      if (bleFidoBadge) {
        bleFidoBadge.textContent = bleFidoCheck.checked ? "Active" : "Disabled";
        bleFidoBadge.className = bleFidoCheck.checked ? "badge ok" : "badge";
      }
    }

    if (typeof d.kvm_enabled === "boolean") qs("kvm-enabled").checked = d.kvm_enabled;
    if (d.kvm_port != null) qs("kvm-port").value = d.kvm_port;
    if (typeof d.kvm_allowed_ip === "string") qs("kvm-allowed-ip").value = d.kvm_allowed_ip;

    updateSliderReadout("typing-delay", " ms");
    updateSliderReadout("burst-chars", "");
    updateSliderReadout("burst-pause", " ms");
    updateSliderReadout("line-delay", " ms");
    updateSliderReadout("kvm-mouse-smooth", "%");

    // Detect which preset matches loaded values and highlight it
    const activePreset = detectActivePreset(
      d.delay ?? 6, d.burst_chars ?? 24, d.burst_pause ?? 10, d.line_delay ?? 40
    );
    requestAnimationFrame(() => setPresetSegment(activePreset));

    // Show dynamic firmware & UI version badges and OTA card info
    if (d.fw_version) {
      const badge = qs("fw-version-badge");
      if (badge) badge.textContent = `FW: v${d.fw_version}`;
      const otaFw = qs("ota-fw-version-display");
      if (otaFw) otaFw.textContent = `v${d.fw_version}`;
    }
    if (d.ui_version) {
      const uiBadge = qs("ui-version-badge");
      if (uiBadge) uiBadge.textContent = `UI: v${d.ui_version}`;
      const otaUi = qs("ota-ui-version-display");
      if (otaUi) otaUi.textContent = `v${d.ui_version}`;
    }
    if (d.build_date) {
      const otaBuild = qs("ota-build-date-display");
      if (otaBuild) otaBuild.textContent = d.build_date;
    }

    updateVendorPresetSelectionFromFields();
    setText("settings-status", "Settings loaded.");
  } catch (_) {
    setText("settings-status", "Network error while loading settings.");
  }
}

async function saveSettings() {
  const usbVid = parseHexOrDecStrict(qs("usb-vendor-id").value);
  const usbPid = parseHexOrDecStrict(qs("usb-product-id").value);

  if (usbVid == null || usbPid == null) {
    setText("settings-status", "USB VID/PID must be valid 16-bit hex or decimal values.");
    return;
  }

  const payload = {
    ap_ssid: qs("ap-ssid").value,
    ap_pass: qs("ap-pass").value,
    sta_ssid: qs("sta-ssid").value,
    sta_pass: qs("sta-pass").value,
    admin_user: qs("admin-user").value,

    delay: Number(qs("typing-delay").value),
    burst_chars: Number(qs("burst-chars").value),
    burst_pause: Number(qs("burst-pause").value),
    line_delay: Number(qs("line-delay").value),
    kvm_mouse_smooth: Number(qs("kvm-mouse-smooth").value),
    bright: Number(qs("led-bright").value),

    login_rate_limit: qs("login-rate-limit").checked,
    proxy_auth_enabled: qs("proxy-auth-enabled").checked,
    proxy_auth_token: qs("proxy-auth-token").value.trim(),

    usb_vendor_name: qs("usb-vendor-name").value.trim(),
    usb_product_name: qs("usb-product-name").value.trim(),
    usb_vid: usbVid,
    usb_pid: usbPid,
    usb_msc_enabled: qs("usb-msc-enabled") ? qs("usb-msc-enabled").checked : true,
    usb_msc_label: qs("usb-msc-label") ? qs("usb-msc-label").value.trim() : "DUCKY_DRIVE",
    usb_msc_backend: qs("usb-msc-backend") ? Number(qs("usb-msc-backend").value) : 0,
    usb_msc_autosave: qs("usb-msc-autosave") ? qs("usb-msc-autosave").checked : false,
    ble_fido_enabled: qs("ble-fido-enabled") ? qs("ble-fido-enabled").checked : false,

    kvm_enabled: qs("kvm-enabled").checked,
    kvm_port: Math.trunc(clampNumber(qs("kvm-port").value, 1, 65535)),
    kvm_allowed_ip: qs("kvm-allowed-ip").value.trim(),
  };

  const newPass = qs("admin-pass").value.trim();
  if (newPass.length > 0) {
    payload.admin_pass = newPass;
  }

  try {
    const res = await api("/api/save_settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      setText("settings-status", "Failed to save settings.");
      return;
    }

    let usbRestart = false;
    let wifiRestart = false;
    let restartNeeded = false;
    try {
      const responseData = await res.json();
      usbRestart = Boolean(responseData.usb_restart_required);
      wifiRestart = Boolean(responseData.wifi_restart_required);
      restartNeeded = Boolean(responseData.restart_required || usbRestart || wifiRestart);
    } catch (_) {}

    qs("admin-pass").value = "";
    if (usbRestart && wifiRestart) {
      setText("settings-status", "⚠️ Settings saved to NVS! A reboot is required to apply new USB descriptors and WiFi network.");
    } else if (usbRestart) {
      setText("settings-status", "⚠️ Settings saved to NVS! A reboot is required to apply new USB hardware VID/PID descriptors.");
    } else if (wifiRestart) {
      setText("settings-status", "⚠️ Settings saved to NVS! A reboot is required to connect to the new WiFi network.");
    } else {
      setText("settings-status", "✅ Settings applied live in real-time! (No reboot needed)");
    }

    updateVendorPresetSelectionFromFields();
    await loadKvmStatus();
  } catch (_) {
    setText("settings-status", "Network error while saving settings.");
  }
}

async function rebootDevice() {
  if (!confirm("Reboot ESP32 now?")) return;
  try {
    await api("/api/reboot", { method: "POST" });
    setText("settings-status", "Reboot command sent. Redirecting to login in 6 seconds...");
    setTimeout(() => {
      window.location.replace("/login");
    }, 6000);
  } catch (_) {
    setText("settings-status", "Failed to send reboot command.");
  }
}

async function logout() {
  try {
    await api("/api/logout", { method: "POST" });
  } catch (_) {}
  window.location.replace("/login");
}

// --- SYSTEM LOGS CONSOLE ---
let sysLogTimer = null;

async function loadSystemLogs() {
  const container = qs("syslog-container");
  if (!container) return;
  try {
    const res = await api("/api/logs");
    if (!res.ok) return;
    const data = await res.json();
    if (!data.logs || data.logs.length === 0) {
      container.textContent = "[No logs recorded yet in circular buffer]";
      return;
    }
    const isScrolledToBottom = container.scrollHeight - container.clientHeight <= container.scrollTop + 40;
    container.textContent = data.logs.join("\n");
    if (isScrolledToBottom) {
      container.scrollTop = container.scrollHeight;
    }
  } catch (_) {}
}

function bindSystemLogs() {
  qs("syslog-refresh-btn")?.addEventListener("click", loadSystemLogs);
  qs("syslog-download-btn")?.addEventListener("click", () => {
    window.open("/api/logs/download", "_blank");
  });
  qs("syslog-clear-btn")?.addEventListener("click", async () => {
    try {
      await api("/api/logs/clear", { method: "POST" });
      loadSystemLogs();
    } catch (_) {}
  });

  if (sysLogTimer) clearInterval(sysLogTimer);
  sysLogTimer = setInterval(() => {
    if (activeTab === "settings" && qs("syslog-auto-refresh")?.checked) {
      loadSystemLogs();
    }
  }, 1000);
}

// --- ENCRYPTED VAULT & 2FA AUTHENTICATOR CLIENT ---
let vaultStatus = { initialized: false, unlocked: false, lock_timeout_sec: 0, entry_count: 0 };
let vaultEntries = [];
let vaultTickerTimer = null;

async function refreshVaultView() {
  try {
    const res = await api("/api/vault/status");
    if (!res.ok) return;
    vaultStatus = await res.json();

    const setupCard = qs("vault-setup-card");
    const lockedCard = qs("vault-locked-card");
    const unlockedCard = qs("vault-unlocked-card");

    if (!vaultStatus.initialized) {
      setupCard?.classList.remove("hidden");
      lockedCard?.classList.add("hidden");
      unlockedCard?.classList.add("hidden");
    } else if (!vaultStatus.unlocked) {
      setupCard?.classList.add("hidden");
      lockedCard?.classList.remove("hidden");
      unlockedCard?.classList.add("hidden");
    } else {
      setupCard?.classList.add("hidden");
      lockedCard?.classList.add("hidden");
      unlockedCard?.classList.remove("hidden");
      await loadFidoStatus();
      await loadYubiKeyStatus();
      await loadVaultEntries();
      startVaultTicker();
    }
  } catch (_) {
    setText("vault-action-status", "Failed to load vault status.");
  }
}

async function loadVaultEntries() {
  try {
    const epoch = Math.floor(Date.now() / 1000);
    const res = await api(`/api/vault/entries?epoch=${epoch}`);
    if (!res.ok) {
      if (res.status === 403) {
        refreshVaultView();
      }
      return;
    }
    const data = await res.json();
    vaultEntries = Array.isArray(data) ? data : [];
    renderVaultEntries();
    setText("vault-action-status", "");
  } catch (err) {
    console.error("loadVaultEntries error", err);
    setText("vault-action-status", "Failed to load entries.");
  }
}

function renderVaultEntries() {
  const grid = qs("vault-items-grid");
  const emptyState = qs("vault-empty-state");
  const search = (qs("vault-search-input")?.value || "").trim().toLowerCase();
  if (!grid) return;

  grid.innerHTML = "";

  const filtered = vaultEntries.filter((item) => {
    if (!search) return true;
    const label = (item.label || "").toLowerCase();
    const user = (item.user || "").toLowerCase();
    const issuer = (item.issuer || "").toLowerCase();
    return label.includes(search) || user.includes(search) || issuer.includes(search);
  });

  if (filtered.length === 0) {
    emptyState?.classList.remove("hidden");
    return;
  }
  emptyState?.classList.add("hidden");

  const isPasskeyMode = !!currentFidoState.security_key_mode;
  const disabledTypeAttr = isPasskeyMode ? 'disabled title="USB Keyboard typing is disabled in Dedicated Passkey Mode. Switch to Normal Ducky Mode to type." style="opacity:0.4; cursor:not-allowed;"' : '';

  filtered.forEach((item) => {
    const card = document.createElement("div");
    card.className = "vault-item";

    const isTotp = (item.type === "totp");
    const title = item.label || (isTotp ? "2FA Authenticator" : "Password Entry");
    const sub = isTotp ? (item.issuer || "TOTP Token") : (item.user || "");

    let innerHtml = `
      <div class="vault-item-head">
        <div>
          <div class="vault-item-title">${escapeHtml(title)}</div>
          <div class="vault-item-sub">${escapeHtml(sub)}</div>
        </div>
        <span class="badge ${isTotp ? "ok" : ""}">${isTotp ? "2FA OTP" : "LOGIN"}</span>
      </div>
    `;

    if (isTotp) {
      const otpCode = item.otp || "000000";
      const remaining = Number.isFinite(item.remaining) ? item.remaining : 30;
      innerHtml += `
        <div class="vault-totp-display">
          <span class="totp-digits" id="otp-digits-${item.id}">${otpCode.slice(0, 3)} ${otpCode.slice(3)}</span>
          <span class="totp-timer" id="otp-timer-${item.id}">${remaining}s</span>
        </div>
        <div class="vault-item-actions">
          <button class="btn-primary btn-sm" ${disabledTypeAttr} data-vault-type="otp" data-vault-id="${item.id}">Type Code + ↵</button>
          <button class="btn-outline btn-sm" data-vault-copy="otp" data-vault-code="${otpCode}">Copy</button>
          <button class="btn-outline btn-sm" data-vault-edit="${item.id}">Edit</button>
          <button class="btn-danger btn-sm" data-vault-del="${item.id}">Delete</button>
        </div>
      `;
    } else {
      const maskedPass = item.pass ? "••••••••••••" : "(empty)";
      innerHtml += `
        <div style="font-family:monospace; font-size:0.9rem; background:rgba(0,0,0,0.3); padding:8px 12px; border-radius:6px;">
          <div>User: <strong style="color:#5fe3a1;">${escapeHtml(item.user || "N/A")}</strong></div>
          <div style="margin-top:4px;">Pass: <span id="pass-text-${item.id}">${maskedPass}</span></div>
        </div>
        <div class="vault-item-actions">
          <button class="btn-primary btn-sm" ${disabledTypeAttr} data-vault-type="both" data-vault-id="${item.id}">Type Both + ↵</button>
          <button class="btn-outline btn-sm" ${disabledTypeAttr} data-vault-type="pass" data-vault-id="${item.id}">Type Pass</button>
          <button class="btn-outline btn-sm" ${disabledTypeAttr} data-vault-type="user" data-vault-id="${item.id}">Type User</button>
          <button class="btn-outline btn-sm" data-vault-reveal="${item.id}">Reveal</button>
          <button class="btn-outline btn-sm" data-vault-edit="${item.id}">Edit</button>
          <button class="btn-danger btn-sm" data-vault-del="${item.id}">Delete</button>
        </div>
      `;
    }

    card.innerHTML = innerHtml;
    grid.appendChild(card);
  });

  // Bind dynamic card actions
  grid.querySelectorAll("[data-vault-type]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.vaultId;
      const action = btn.dataset.vaultType;
      await typeVaultEntry(id, action);
    });
  });

  grid.querySelectorAll("[data-vault-copy]").forEach((btn) => {
    btn.addEventListener("click", () => {
      copyTextToClipboard(btn.dataset.vaultCode, "2FA OTP code copied.");
    });
  });

  grid.querySelectorAll("[data-vault-reveal]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.dataset.vaultReveal;
      const item = vaultEntries.find((e) => e.id === id);
      const span = qs(`pass-text-${id}`);
      if (item && span) {
        if (span.textContent === "••••••••••••") {
          span.textContent = item.pass;
          btn.textContent = "Hide";
        } else {
          span.textContent = "••••••••••••";
          btn.textContent = "Reveal";
        }
      }
    });
  });

  grid.querySelectorAll("[data-vault-edit]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.dataset.vaultEdit;
      const item = vaultEntries.find((e) => e.id === id);
      if (item) openVaultModal(item);
    });
  });

  grid.querySelectorAll("[data-vault-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.vaultDel;
      if (confirm("Delete this vault item?")) {
        await deleteVaultEntry(id);
      }
    });
  });
}

// --- FIDO2 / WEBAUTHN PASSKEYS DASHBOARD ---
let currentFidoState = { pin_set: false, pin_retries: 8 };

async function loadFidoStatus() {
  const list = qs("fido-passkeys-list");
  const touchBadge = qs("fido-touch-badge");
  const pinBadge = qs("fido-pin-badge");
  const managePinBtn = qs("fido-manage-pin-btn");
  if (!list) return;
  try {
    const res = await api("/api/fido/status");
    if (!res.ok) return;
    const data = await res.json();
    currentFidoState = data;

    const modeBadge = qs("fido-mode-badge");
    const toggleBtn = qs("fido-toggle-mode-btn");
    if (modeBadge) {
      if (data.security_key_mode) {
        modeBadge.className = "badge";
        modeBadge.style.background = "#00f3ff";
        modeBadge.style.color = "#070b14";
        modeBadge.textContent = "🛡️ Dedicated Passkey Mode";
      } else {
        modeBadge.className = "badge ok";
        modeBadge.textContent = "💻 Normal Ducky Mode";
      }
    }
    if (toggleBtn) {
      toggleBtn.textContent = data.security_key_mode ? "💻 Switch to Normal Ducky Mode" : "🛡️ Switch to Passkey Mode";
    }

    if (pinBadge) {
      if (data.pin_set) {
        pinBadge.className = "badge ok";
        pinBadge.textContent = `🔑 PIN: Configured (${data.pin_retries ?? 8}/8 retries)`;
      } else {
        pinBadge.className = "badge";
        pinBadge.textContent = "🔓 PIN: Not Set";
      }
    }

    if (managePinBtn) {
      managePinBtn.textContent = data.pin_set ? "🔑 Change / Remove PIN" : "🔑 Set PIN";
    }

    loadKeePassStatus();

    const uvToggle = qs("fido-emulate-uv-toggle");
    const uvBadge = qs("fido-uv-badge");
    if (uvToggle) {
      uvToggle.checked = !!data.emulate_uv;
    }
    if (uvBadge) {
      if (data.emulate_uv) {
        uvBadge.className = "badge ok";
        uvBadge.textContent = "⚡ Emulated UV=true";
      } else {
        uvBadge.className = "badge";
        uvBadge.textContent = "Standard UV=false";
      }
    }

    if (touchBadge) {
      touchBadge.classList.toggle("hidden", !data.waiting_for_touch);
      if (data.waiting_for_touch) {
        touchBadge.textContent = data.pending_rp ? `⚠️ Touch BOOT for ${data.pending_rp}` : "⚠️ Touch BOOT Button";
      }
    }

    list.innerHTML = "";
    if (!data.credentials || data.credentials.length === 0) {
      list.innerHTML = '<div class="small" style="padding:10px; color:var(--muted); text-align:center;">No hardware passkeys registered yet. Click <strong>Test Passkey</strong> or register on any website (e.g. webauthn.io, GitHub, Google).</div>';
      return;
    }

    data.credentials.forEach((c) => {
      const item = document.createElement("div");
      item.className = "file-item";
      item.style.display = "flex";
      item.style.justifyContent = "space-between";
      item.style.alignItems = "center";
      item.innerHTML = `
        <div style="display:flex; align-items:center; gap:8px;">
          <span>🔑</span>
          <div>
            <strong>${escapeHtml(c.rpId)}</strong>
            <div class="small" style="color:var(--muted); font-size:11px;">User: ${escapeHtml(c.userName || "N/A")} • Counter: ${c.signCounter}</div>
          </div>
        </div>
        <div style="display:flex; align-items:center; gap:6px;">
          <span class="badge ok" style="font-size:10px;">Hardware Resident</span>
          <button type="button" class="btn-outline btn-sm fido-inspect-cred-btn" style="font-size:10px; padding:2px 8px; color:#00f3ff; border-color:rgba(0,243,255,0.3);">👁️ Details</button>
          <button type="button" class="btn-outline btn-sm fido-del-cred-btn" data-id="${escapeHtml(c.credId || '')}" style="color:var(--danger); border-color:rgba(244,63,94,0.3); font-size:10px; padding:2px 6px;">🗑️</button>
        </div>
      `;

      const inspectBtn = item.querySelector(".fido-inspect-cred-btn");
      inspectBtn?.addEventListener("click", () => {
        openFidoInspectModal(c);
      });

      const delBtn = item.querySelector(".fido-del-cred-btn");
      delBtn?.addEventListener("click", async () => {
        if (!confirm(`Delete passkey for ${c.rpId}?`)) return;
        try {
          await api("/api/fido/credential/delete", {
            method: "POST",
            body: JSON.stringify({ credId: c.credId })
          });
          setText("fido-status-msg", `Passkey for ${c.rpId} deleted.`);
          await loadFidoStatus();
        } catch (_) {
          setText("fido-status-msg", "Failed to delete passkey.");
        }
      });
      list.appendChild(item);
    });
  } catch (_) {}
}

function openFidoInspectModal(c) {
  const modal = qs("fido-inspect-modal");
  if (!modal) return;

  setText("inspect-rp-id", c.rpId || "N/A");
  setText("inspect-user-name", c.userName || "N/A");
  setText("inspect-display-name", c.userDisplayName || "N/A");
  setText("inspect-sign-counter", String(c.signCounter ?? 0));
  setText("inspect-created-at", c.createdAt ? new Date(c.createdAt * 1000).toLocaleString() : "N/A");

  setValue("inspect-cred-id", c.credId || "N/A");
  if (c.pubKeyX && c.pubKeyY) {
    setValue("inspect-pub-key", `X: ${c.pubKeyX}\nY: ${c.pubKeyY}`);
  } else {
    setValue("inspect-pub-key", "N/A");
  }

  const hmacBadge = qs("inspect-hmac-badge");
  if (hmacBadge) {
    if (c.hasHmacSecret) {
      hmacBadge.className = "badge ok";
      hmacBadge.textContent = "✅ Supported (WebAuthn PRF Enabled)";
    } else {
      hmacBadge.className = "badge";
      hmacBadge.textContent = "Standard Credential";
    }
  }

  const policySelect = qs("inspect-cred-policy-select");
  const policyBadge = qs("inspect-policy-badge");
  setText("inspect-policy-status", "");

  const updateBadge = (lvl) => {
    if (!policyBadge) return;
    if (lvl === 3) {
      policyBadge.className = "badge";
      policyBadge.style.background = "#f43f5e";
      policyBadge.style.color = "#ffffff";
      policyBadge.textContent = "🔴 Level 3: Strict PIN";
    } else if (lvl === 2) {
      policyBadge.className = "badge";
      policyBadge.style.background = "#f59e0b";
      policyBadge.style.color = "#070b14";
      policyBadge.textContent = "🟡 Level 2: Smart";
    } else {
      policyBadge.className = "badge ok";
      policyBadge.textContent = "🟢 Level 1: Standard";
    }
  };

  if (policySelect) {
    const curPolicy = Number(c.credProtect || 1);
    policySelect.value = String(curPolicy);
    updateBadge(curPolicy);

    policySelect.onchange = async () => {
      const newPolicy = Number(policySelect.value);
      updateBadge(newPolicy);
      try {
        setText("inspect-policy-status", "Updating policy...");
        const res = await api("/api/fido/credential/policy", {
          method: "POST",
          body: JSON.stringify({ credId: c.credId, credProtect: newPolicy })
        });
        if (res.ok) {
          c.credProtect = newPolicy;
          setText("inspect-policy-status", "✅ Policy saved!");
        } else {
          setText("inspect-policy-status", "Failed to update policy.");
        }
      } catch (_) {
        setText("inspect-policy-status", "Network error.");
      }
    };
  }

  modal.classList.remove("hidden");
}

function closeFidoInspectModal() {
  qs("fido-inspect-modal")?.classList.add("hidden");
}

function bindFidoControls() {
  qs("fido-toggle-mode-btn")?.addEventListener("click", async () => {
    try {
      setText("fido-status-msg", "Switching USB profile & rebooting device...");
      await api("/api/fido/mode", { method: "POST", body: "{}" });
      setTimeout(() => {
        window.location.reload();
      }, 2500);
    } catch (_) {
      setText("fido-status-msg", "Failed to switch USB mode.");
    }
  });

  qs("fido-refresh-btn")?.addEventListener("click", loadFidoStatus);

  // PIN Management Modal Controls
  const pinModal = qs("fido-pin-modal");
  const openPinModal = () => {
    if (!pinModal) return;
    const isSet = currentFidoState.pin_set;
    setText("fido-pin-modal-title", isSet ? "🔑 Change Security Key PIN" : "🔑 Set Security Key PIN");
    setText("fido-pin-modal-desc", isSet ? "Update your existing PIN or remove it." : "Set a new 4-8 digit hardware PIN to protect your passkeys.");
    qs("fido-current-pin-group")?.classList.toggle("hidden", !isSet);
    qs("fido-remove-pin-btn")?.classList.toggle("hidden", !isSet);
    
    setValue("fido-input-current-pin", "");
    setValue("fido-input-new-pin", "");
    setValue("fido-input-confirm-pin", "");
    setText("fido-pin-status-msg", "");
    pinModal.classList.remove("hidden");
  };

  const closePinModal = () => {
    pinModal?.classList.add("hidden");
  };

  qs("fido-manage-pin-btn")?.addEventListener("click", openPinModal);
  qs("fido-pin-modal-close")?.addEventListener("click", closePinModal);
  qs("fido-pin-cancel-btn")?.addEventListener("click", closePinModal);

  qs("fido-save-pin-btn")?.addEventListener("click", async () => {
    const isSet = currentFidoState.pin_set;
    const currentPin = qs("fido-input-current-pin")?.value.trim() || "";
    const newPin = qs("fido-input-new-pin")?.value.trim() || "";
    const confirmPin = qs("fido-input-confirm-pin")?.value.trim() || "";

    if (isSet && !currentPin) {
      setText("fido-pin-status-msg", "Please enter your current PIN.");
      return;
    }
    if (newPin.length < 4) {
      setText("fido-pin-status-msg", "New PIN must be at least 4 digits.");
      return;
    }
    if (newPin !== confirmPin) {
      setText("fido-pin-status-msg", "New PIN and confirmation do not match.");
      return;
    }

    try {
      setText("fido-pin-status-msg", "Saving PIN to hardware vault...");
      const res = await api("/api/fido/pin", {
        method: "POST",
        body: JSON.stringify({ action: "set", currentPin, newPin })
      });
      const data = await res.json();
      if (!res.ok) {
        setText("fido-pin-status-msg", data.error || "Failed to update PIN.");
        return;
      }
      setText("fido-status-msg", "✅ Security Key PIN updated successfully!");
      closePinModal();
      await loadFidoStatus();
    } catch (err) {
      setText("fido-pin-status-msg", "Error updating PIN.");
    }
  });

  qs("fido-remove-pin-btn")?.addEventListener("click", async () => {
    if (!confirm("Are you sure you want to remove the PIN? Your passkeys will remain usable without a PIN.")) return;
    try {
      setText("fido-pin-status-msg", "Removing PIN...");
      const res = await api("/api/fido/pin", {
        method: "POST",
        body: JSON.stringify({ action: "remove" })
      });
      if (!res.ok) {
        setText("fido-pin-status-msg", "Failed to remove PIN.");
        return;
      }
      setText("fido-status-msg", "✅ Security Key PIN removed.");
      closePinModal();
      await loadFidoStatus();
    } catch (_) {
      setText("fido-pin-status-msg", "Error removing PIN.");
    }
  });

  qs("fido-reset-btn")?.addEventListener("click", async () => {
    if (!confirm("⚠️ Factory Reset Security Key? This will wipe all registered FIDO2 / WebAuthn passkeys and reset the PIN.")) return;
    try {
      await api("/api/fido/reset", { method: "POST" });
      setText("fido-status-msg", "All hardware passkeys and PIN wiped (Factory Reset complete).");
      await loadFidoStatus();
    } catch (_) {
      setText("fido-status-msg", "Failed to reset security key.");
    }
  });

  qs("fido-emulate-uv-toggle")?.addEventListener("change", async (e) => {
    const enabled = e.target.checked;
    try {
      setText("fido-status-msg", enabled ? "Enabling Biometric UV Emulation (UV=true)..." : "Setting Standard Roaming Mode (UV=false)...");
      await api("/api/fido/emulate_uv", {
        method: "POST",
        body: JSON.stringify({ enabled })
      });
      setText("fido-status-msg", enabled ? "⚡ Biometric UV Emulation ENABLED (Active instantly without reboot)." : "Standard Roaming Key Mode active.");
      await loadFidoStatus();
    } catch (_) {
      setText("fido-status-msg", "Failed to update UV emulation setting.");
    }
  });

  qs("fido-test-register-btn")?.addEventListener("click", async () => {
    if (!window.PublicKeyCredential || !window.isSecureContext) {
      setText("fido-status-msg", "WebAuthn requires HTTPS for security isolation. Opening https://webauthn.io in a new tab to test your security key...");
      window.open("https://webauthn.io", "_blank");
      return;
    }
    try {
      setText("fido-status-msg", "Press physical BOOT button on ESP32 to authorize passkey creation...");
      const challenge = new Uint8Array(32);
      window.crypto.getRandomValues(challenge);
      const userId = new Uint8Array(16);
      window.crypto.getRandomValues(userId);

      const credential = await navigator.credentials.create({
        publicKey: {
          challenge: challenge,
          rp: { name: "ESP32-S3 Security Key Test", id: window.location.hostname },
          user: {
            id: userId,
            name: "admin@esp32.local",
            displayName: "ESP32 Operator"
          },
          pubKeyCredParams: [{ type: "public-key", alg: -7 }],
          authenticatorSelection: {
            authenticatorAttachment: "cross-platform",
            userVerification: "discouraged"
          },
          timeout: 30000
        }
      });
      if (credential) {
        setText("fido-status-msg", "✅ Passkey created successfully on ESP32-S3 hardware!");
        await loadFidoStatus();
      }
    } catch (err) {
      console.error("WebAuthn test error", err);
      setText("fido-status-msg", "Test result: " + (err.message || "Completed"));
      await loadFidoStatus();
    }
  });

  bindKeePassControls();
  bindBip39Controls();
}

async function loadKeePassStatus() {
  try {
    const res = await api("/api/keepass/status");
    const data = await res.json();
    const badge = qs("keepass-status-badge");
    if (badge) {
      if (data.configured) {
        badge.className = "badge ok";
        badge.textContent = "✅ Configured (Active)";
      } else {
        badge.className = "badge";
        badge.textContent = "Not Configured";
      }
    }
    if (data.secret_hex) setValue("keepass-secret-hex", data.secret_hex);
    if (data.secret_base32) setValue("keepass-secret-b32", data.secret_base32);
  } catch (_) {}
}

function bindKeePassControls() {
  qs("keepass-generate-btn")?.addEventListener("click", async () => {
    try {
      setText("keepass-status-msg", "Generating random secret...");
      const res = await api("/api/keepass/config", {
        method: "POST",
        body: JSON.stringify({ action: "generate" })
      });
      const data = await res.json();
      if (data.ok) {
        setValue("keepass-secret-hex", data.secret_hex);
        setValue("keepass-secret-b32", data.secret_base32);
        const badge = qs("keepass-status-badge");
        if (badge) { badge.className = "badge ok"; badge.textContent = "✅ Configured (Active)"; }
        setText("keepass-status-msg", "✅ New secret generated! Copy Base32 into KeePassXC.");
      }
    } catch (_) {
      setText("keepass-status-msg", "Failed to generate secret.");
    }
  });

  qs("keepass-save-btn")?.addEventListener("click", async () => {
    const hex = qs("keepass-secret-hex")?.value.trim() || "";
    if (hex.length !== 40) {
      setText("keepass-status-msg", "Secret hex must be exactly 40 hex characters (20 bytes).");
      return;
    }
    try {
      setText("keepass-status-msg", "Saving secret...");
      const res = await api("/api/keepass/config", {
        method: "POST",
        body: JSON.stringify({ action: "set", secret_hex: hex })
      });
      const data = await res.json();
      if (data.ok) {
        setValue("keepass-secret-b32", data.secret_base32);
        const badge = qs("keepass-status-badge");
        if (badge) { badge.className = "badge ok"; badge.textContent = "✅ Configured (Active)"; }
        setText("keepass-status-msg", "✅ Secret saved to hardware flash!");
      } else {
        setText("keepass-status-msg", data.error || "Failed to save secret.");
      }
    } catch (_) {
      setText("keepass-status-msg", "Network error.");
    }
  });

  qs("keepass-clear-btn")?.addEventListener("click", async () => {
    if (!confirm("Clear KeePassXC secret key?")) return;
    try {
      await api("/api/keepass/config", { method: "POST", body: JSON.stringify({ action: "clear" }) });
      setValue("keepass-secret-hex", "");
      setValue("keepass-secret-b32", "");
      const badge = qs("keepass-status-badge");
      if (badge) { badge.className = "badge"; badge.textContent = "Not Configured"; }
      setText("keepass-status-msg", "Secret cleared.");
    } catch (_) {}
  });

  qs("keepass-copy-hex")?.addEventListener("click", () => {
    const val = qs("keepass-secret-hex")?.value || "";
    if (val) {
      navigator.clipboard.writeText(val);
      setText("keepass-status-msg", "Hex secret copied to clipboard.");
    }
  });

  qs("keepass-copy-b32")?.addEventListener("click", () => {
    const val = qs("keepass-secret-b32")?.value || "";
    if (val) {
      navigator.clipboard.writeText(val);
      setText("keepass-status-msg", "Base32 secret copied to clipboard! (Paste into KeePassXC)");
    }
  });
}

function bindBip39Controls() {
  qs("bip39-generate-btn")?.addEventListener("click", async () => {
    try {
      setText("bip39-status-msg", "Generating 256-bit entropy from hardware TRNG...");
      const res = await api("/api/bip39/generate");
      const data = await res.json();
      if (data.ok && data.mnemonic) {
        const box = qs("bip39-phrase-box");
        const grid = qs("bip39-grid");
        if (box && grid) {
          grid.innerHTML = "";
          const words = data.mnemonic.split(" ");
          words.forEach((w, idx) => {
            const chip = document.createElement("div");
            chip.style.cssText = "background:rgba(168,85,247,0.1); border:1px solid rgba(168,85,247,0.25); border-radius:6px; padding:6px 10px; font-family:monospace; font-size:0.82rem;";
            chip.innerHTML = `<span style="color:var(--muted); font-size:10px; margin-right:6px;">${idx + 1}.</span><strong>${escapeHtml(w)}</strong>`;
            grid.appendChild(chip);
          });
          box.classList.remove("hidden");
        }
        setText("bip39-status-msg", "✅ 24-word recovery phrase generated!");

        qs("bip39-copy-phrase")?.addEventListener("click", () => {
          navigator.clipboard.writeText(data.mnemonic);
          setText("bip39-status-msg", "24-word phrase copied to clipboard.");
        });
      }
    } catch (_) {
      setText("bip39-status-msg", "Failed to generate mnemonic.");
    }
  });
}

// --- YUBIKEY EMULATION JAVASCRIPT CONTROLLER ---

let yubiKeyState = {
  yubikey_mode: false,
  serial_number: 17869661,
  slot1: { mode: 1, public_id: "cccccccccccb" },
  slot2: { mode: 2, public_id: "cccccccccccf" },
};

async function loadYubiKeyStatus() {
  try {
    const res = await api("/api/yubikey/status");
    if (!res.ok) return;
    const data = await res.json();
    yubiKeyState = data;

    const isYubi = Boolean(data.yubikey_mode);
    const badge = qs("yubikey-profile-badge");
    if (badge) {
      badge.textContent = isYubi ? "YubiKey 5 Mode" : "Standard FIDO2";
      badge.className = isYubi ? "badge ok" : "badge";
    }

    const toggleBtn = qs("yubikey-toggle-profile-btn");
    if (toggleBtn) {
      toggleBtn.textContent = isYubi ? "Switch to Standard Mode" : "Switch to YubiKey Mode";
    }

    const details = qs("yubikey-details-panel");
    if (details) {
      details.style.display = isYubi ? "block" : "none";
    }

    // Populate Slot 1
    if (data.slot1) {
      setValue("yubi-s1-mode", String(data.slot1.mode));
      setValue("yubi-s1-pubid", data.slot1.public_id || "cccccccccccb");
      syncYubiSlotUi(1, data.slot1.mode);
    }

    // Populate Slot 2
    if (data.slot2) {
      setValue("yubi-s2-mode", String(data.slot2.mode));
      setValue("yubi-s2-pubid", data.slot2.public_id || "cccccccccccf");
      syncYubiSlotUi(2, data.slot2.mode);
    }

    if (isYubi) {
      await loadYubiOathAccounts();
    }
  } catch (_) {}
}

function syncYubiSlotUi(slot, mode) {
  const isOtp = (Number(mode) === 1);
  const isStatic = (Number(mode) === 2);
  const prefix = (slot === 2) ? "yubi-s2" : "yubi-s1";

  const otpFields = qs(`${prefix}-otp-fields`);
  const staticFields = qs(`${prefix}-static-fields`);
  const badge = qs(`${prefix}-badge`);

  if (otpFields) otpFields.style.display = isOtp ? "block" : "none";
  if (staticFields) staticFields.style.display = isStatic ? "block" : "none";
  if (badge) {
    if (isOtp) { badge.textContent = "Yubico OTP"; badge.className = "badge ok"; }
    else if (isStatic) { badge.textContent = "Static Password"; badge.className = "badge"; }
    else { badge.textContent = "Disabled"; badge.className = "badge"; }
  }
}

async function saveYubiSlot(slot) {
  const prefix = (slot === 2) ? "yubi-s2" : "yubi-s1";
  const mode = Number(qs(`${prefix}-mode`)?.value || 0);
  const publicId = qs(`${prefix}-pubid`)?.value.trim() || "";
  const staticPass = qs(`${prefix}-static`)?.value || "";

  setText("yubi-status-msg", `Saving Slot ${slot}...`);
  try {
    const res = await api("/api/yubikey/slot/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        slot: slot,
        mode: mode,
        public_id: publicId,
        static_password: staticPass,
        send_enter: true
      })
    });
    if (res.ok) {
      setText("yubi-status-msg", `✅ Slot ${slot} saved successfully.`);
      syncYubiSlotUi(slot, mode);
    } else {
      setText("yubi-status-msg", `❌ Failed to save Slot ${slot}.`);
    }
  } catch (_) {
    setText("yubi-status-msg", `❌ Network error while saving Slot ${slot}.`);
  }
}

async function testYubiSlot(slot) {
  setText("yubi-status-msg", `Injecting Slot ${slot} over USB keyboard...`);
  try {
    const res = await api(`/api/yubikey/slot/test?slot=${slot}`, { method: "POST" });
    const data = await res.json();
    if (res.ok && data.ok) {
      setText("yubi-status-msg", `✅ Slot ${slot} typed (${data.typed_length} chars).`);
    } else {
      setText("yubi-status-msg", `❌ ${data.error || "Failed to type slot"}`);
    }
  } catch (_) {
    setText("yubi-status-msg", "❌ Network error.");
  }
}

async function loadYubiOathAccounts() {
  const container = qs("yubi-oath-list");
  if (!container) return;
  try {
    const res = await api("/api/yubikey/oath/accounts");
    if (!res.ok) return;
    const data = await res.json();
    const accounts = data.accounts || [];

    if (!accounts.length) {
      container.innerHTML = '<div style="color:var(--muted); font-size:11px; grid-column:1/-1;">No 2FA accounts stored on YubiKey. Click "+ Add 2FA Secret" to add one.</div>';
      return;
    }

    container.innerHTML = "";
    accounts.forEach((acc) => {
      const card = document.createElement("div");
      card.style.cssText = "background:rgba(255,255,255,0.03); border:1px solid var(--line); border-radius:6px; padding:8px 10px; display:flex; justify-content:space-between; align-items:center;";

      const left = document.createElement("div");
      const title = document.createElement("div");
      title.style.cssText = "font-weight:600; font-size:12px; color:#fff;";
      title.textContent = acc.name;

      const codeRow = document.createElement("div");
      codeRow.style.cssText = "display:flex; align-items:center; gap:8px; margin-top:2px;";

      const codeSpan = document.createElement("span");
      codeSpan.style.cssText = "font-family:'JetBrains Mono', monospace; font-weight:700; font-size:16px; color:#00f3ff; letter-spacing:2px;";
      codeSpan.textContent = acc.code || "------";

      const remSpan = document.createElement("span");
      remSpan.style.cssText = "font-size:10px; color:var(--muted);";
      remSpan.textContent = `${acc.remaining_sec || 30}s`;

      codeRow.appendChild(codeSpan);
      codeRow.appendChild(remSpan);
      left.appendChild(title);
      left.appendChild(codeRow);

      const right = document.createElement("div");
      right.style.cssText = "display:flex; gap:4px;";

      const copyBtn = document.createElement("button");
      copyBtn.className = "btn-outline btn-sm";
      copyBtn.style.cssText = "padding:2px 6px; font-size:10px;";
      copyBtn.textContent = "Copy";
      copyBtn.addEventListener("click", () => {
        if (acc.code) copyTextToClipboard(acc.code, `Copied ${acc.name} 2FA code`);
      });

      const delBtn = document.createElement("button");
      delBtn.className = "btn-danger btn-sm";
      delBtn.style.cssText = "padding:2px 5px; font-size:10px;";
      delBtn.textContent = "✕";
      delBtn.title = "Delete account";
      delBtn.addEventListener("click", async () => {
        if (!confirm(`Delete 2FA account '${acc.name}' from YubiKey?`)) return;
        try {
          await api(`/api/yubikey/oath/delete?name=${encodeURIComponent(acc.name)}`, { method: "POST" });
          loadYubiOathAccounts();
        } catch (_) {}
      });

      right.appendChild(copyBtn);
      right.appendChild(delBtn);
      card.appendChild(left);
      card.appendChild(right);
      container.appendChild(card);
    });
  } catch (_) {}
}

function bindYubiKeyEvents() {
  qs("yubikey-refresh-btn")?.addEventListener("click", loadYubiKeyStatus);

  qs("yubikey-toggle-profile-btn")?.addEventListener("click", async () => {
    const nextMode = !yubiKeyState.yubikey_mode;
    setText("yubi-status-msg", nextMode ? "Enabling YubiKey 5 Profile..." : "Restoring Standard FIDO2 Profile...");
    try {
      const res = await api(`/api/yubikey/mode?enabled=${nextMode ? "1" : "0"}`, { method: "POST" });
      if (res.ok) {
        await loadYubiKeyStatus();
        setText("yubi-status-msg", nextMode ? "✅ YubiKey 5 Mode Active! Reboot device to apply USB identity." : "✅ Standard FIDO2 Mode Active! Reboot device to apply.");
      }
    } catch (_) {
      setText("yubi-status-msg", "❌ Failed to change profile.");
    }
  });

  qs("yubi-s1-mode")?.addEventListener("change", (e) => syncYubiSlotUi(1, e.target.value));
  qs("yubi-s2-mode")?.addEventListener("change", (e) => syncYubiSlotUi(2, e.target.value));

  qs("yubi-s1-save-btn")?.addEventListener("click", () => saveYubiSlot(1));
  qs("yubi-s2-save-btn")?.addEventListener("click", () => saveYubiSlot(2));

  qs("yubi-s1-test-btn")?.addEventListener("click", () => testYubiSlot(1));
  qs("yubi-s2-test-btn")?.addEventListener("click", () => testYubiSlot(2));

  // OATH Modal Controls
  const oathModal = qs("yubi-oath-modal");
  qs("yubi-oath-add-btn")?.addEventListener("click", () => {
    setValue("yubi-oath-name", "");
    setValue("yubi-oath-secret", "");
    setValue("yubi-oath-issuer", "");
    setValue("yubi-oath-digits", "6");
    oathModal?.classList.remove("hidden");
  });

  qs("yubi-oath-modal-close")?.addEventListener("click", () => oathModal?.classList.add("hidden"));
  qs("yubi-oath-cancel-btn")?.addEventListener("click", () => oathModal?.classList.add("hidden"));

  qs("yubi-oath-save-btn")?.addEventListener("click", async () => {
    const name = qs("yubi-oath-name")?.value.trim() || "";
    const secret = qs("yubi-oath-secret")?.value.trim().toUpperCase() || "";
    const issuer = qs("yubi-oath-issuer")?.value.trim() || "";
    const digits = Number(qs("yubi-oath-digits")?.value || 6);

    if (!name || !secret) {
      alert("Name and Base32 secret are required.");
      return;
    }

    try {
      const res = await api("/api/yubikey/oath/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name,
          secret: secret,
          issuer: issuer,
          digits: digits,
          period: 30,
          algo: "SHA1"
        })
      });
      if (res.ok) {
        oathModal?.classList.add("hidden");
        loadYubiOathAccounts();
      } else {
        alert("Failed to save OATH secret to YubiKey.");
      }
    } catch (_) {
      alert("Network error.");
    }
  });
}

function startVaultTicker() {
  if (vaultTickerTimer) clearInterval(vaultTickerTimer);

  vaultTickerTimer = setInterval(async () => {
    if (activeTab !== "vault") return;
    if (!vaultStatus.unlocked) {
      clearInterval(vaultTickerTimer);
      vaultTickerTimer = null;
      return;
    }

    if (vaultStatus.lock_timeout_sec > 0) {
      vaultStatus.lock_timeout_sec--;
      const min = Math.floor(vaultStatus.lock_timeout_sec / 60);
      const sec = String(vaultStatus.lock_timeout_sec % 60).padStart(2, "0");
      const badge = qs("vault-autolock-badge");
      if (badge) badge.textContent = `Auto-locks in ${min}:${sec}`;

      if (vaultStatus.lock_timeout_sec <= 0) {
        clearInterval(vaultTickerTimer);
        vaultTickerTimer = null;
        await refreshVaultView();
        return;
      }
    }

    let needRefresh = false;
    vaultEntries.forEach((item) => {
      if (item.type === "totp" && typeof item.remaining === "number") {
        item.remaining--;
        const timerSpan = qs(`otp-timer-${item.id}`);
        if (timerSpan) timerSpan.textContent = `${item.remaining}s`;
        if (item.remaining <= 0) needRefresh = true;
      }
    });

    if (needRefresh) {
      loadVaultEntries();
    }
  }, 1000);
}

async function typeVaultEntry(id, action) {
  if (currentFidoState.security_key_mode) {
    setText("vault-action-status", "⚠️ USB Keyboard typing is disabled in Dedicated Passkey Mode. Use 'Copy' or switch to Normal Ducky Mode.");
    return;
  }
  try {
    setText("vault-action-status", "Typing via USB HID...");
    const res = await api("/api/vault/type", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, action, enter: true }),
    });
    if (!res.ok) throw new Error();
    setText("vault-action-status", "Typed successfully via USB HID.");
  } catch (_) {
    setText("vault-action-status", "Failed to type entry.");
  }
}

async function deleteVaultEntry(id) {
  try {
    const res = await api("/api/vault/entry/delete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    if (!res.ok) throw new Error();
    await loadVaultEntries();
    setText("vault-action-status", "Item deleted.");
  } catch (_) {
    setText("vault-action-status", "Failed to delete item.");
  }
}

function openVaultModal(item = null) {
  const modal = qs("vault-modal");
  if (!modal) return;

  qs("vault-item-id").value = item ? item.id : "";
  qs("vault-item-type").value = item ? (item.type || "totp") : "totp";
  qs("vault-item-label").value = item ? (item.label || "") : "";
  qs("vault-item-secret").value = item ? (item.secret || "") : "";
  qs("vault-item-digits").value = item ? String(item.digits || 6) : "6";
  qs("vault-item-period").value = item ? String(item.period || 30) : "30";
  qs("vault-item-user").value = item ? (item.user || "") : "";
  qs("vault-item-pass").value = item ? (item.pass || "") : "";
  qs("vault-item-notes").value = item ? (item.notes || "") : "";
  qs("vault-modal-title").textContent = item ? "Edit Vault Entry" : "Add Vault Entry";

  syncVaultModalFields();
  modal.classList.remove("hidden");
}

function closeVaultModal() {
  qs("vault-modal")?.classList.add("hidden");
}

function syncVaultModalFields() {
  const type = qs("vault-item-type")?.value || "totp";
  if (type === "totp") {
    qs("vault-totp-fields")?.classList.remove("hidden");
    qs("vault-pass-fields")?.classList.add("hidden");
  } else {
    qs("vault-totp-fields")?.classList.add("hidden");
    qs("vault-pass-fields")?.classList.remove("hidden");
  }
}

function bindVaultEvents() {
  qs("vault-setup-btn")?.addEventListener("click", async () => {
    const p1 = qs("vault-setup-pass")?.value || "";
    const p2 = qs("vault-setup-pass-confirm")?.value || "";
    if (p1.length < 6) {
      setText("vault-setup-status", "Password must be at least 6 characters.");
      return;
    }
    if (p1 !== p2) {
      setText("vault-setup-status", "Passwords do not match.");
      return;
    }
    try {
      setText("vault-setup-status", "Initializing encrypted vault (deriving AES-256 key)...");
      const res = await api("/api/vault/setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: p1 }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        setText("vault-setup-status", err.error || "Failed to setup vault.");
        return;
      }
      qs("vault-setup-pass").value = "";
      qs("vault-setup-pass-confirm").value = "";
      setText("vault-setup-status", "");
      await refreshVaultView();
    } catch (_) {
      setText("vault-setup-status", "Failed to setup vault.");
    }
  });

  qs("vault-unlock-btn")?.addEventListener("click", async () => {
    const passInput = qs("vault-unlock-pass");
    const pass = passInput?.value || "";
    if (!pass) {
      setStatusMsg("vault-lock-status", "Please enter your Master Password.", "error");
      passInput?.focus();
      return;
    }
    try {
      setStatusMsg("vault-lock-status", "Decrypting vault in RAM...");
      const res = await api("/api/vault/unlock", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pass, epoch: Math.floor(Date.now() / 1000) }),
      });
      if (!res.ok) {
        setStatusMsg("vault-lock-status", "⚠️ Incorrect Master Password. Please try again.", "error");
        passInput?.classList.remove("input-error");
        void passInput?.offsetWidth;
        passInput?.classList.add("input-error");
        passInput?.focus();
        passInput?.select();
        return;
      }
      passInput.value = "";
      passInput.classList.remove("input-error");
      setStatusMsg("vault-lock-status", "");
      await refreshVaultView();
    } catch (_) {
      setStatusMsg("vault-lock-status", "⚠️ Incorrect Master Password. Please try again.", "error");
      passInput?.classList.remove("input-error");
      void passInput?.offsetWidth;
      passInput?.classList.add("input-error");
      passInput?.focus();
      passInput?.select();
    }
  });

  qs("vault-unlock-pass")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      qs("vault-unlock-btn")?.click();
    }
  });

  qs("vault-setup-pass-confirm")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      qs("vault-setup-btn")?.click();
    }
  });

  qs("vault-lock-btn")?.addEventListener("click", async () => {
    try {
      await api("/api/vault/lock", { method: "POST" });
      refreshVaultView();
    } catch (_) {}
  });

  qs("vault-reset-btn")?.addEventListener("click", async () => {
    if (!confirm("⚠️ WARNING: Resetting the vault will erase the existing encrypted vault and any stored 2FA keys so you can set a brand new Master Password.\n\nAre you sure you want to reset?")) {
      return;
    }
    try {
      const res = await api("/api/vault/reset", { method: "POST" });
      if (!res.ok) throw new Error();
      await refreshVaultView();
    } catch (_) {
      alert("Failed to reset vault.");
    }
  });

  qs("vault-search-input")?.addEventListener("input", renderVaultEntries);
  qs("vault-add-item-btn")?.addEventListener("click", () => openVaultModal(null));
  qs("vault-modal-close")?.addEventListener("click", closeVaultModal);
  qs("vault-modal-cancel")?.addEventListener("click", closeVaultModal);
  qs("vault-item-type")?.addEventListener("change", syncVaultModalFields);

  qs("vault-gen-pass-btn")?.addEventListener("click", () => {
    const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%^&*";
    let pass = "";
    for (let i = 0; i < 20; i++) {
      pass += chars[Math.floor(Math.random() * chars.length)];
    }
    if (qs("vault-item-pass")) qs("vault-item-pass").value = pass;
  });

  qs("vault-modal-save")?.addEventListener("click", async () => {
    const type = qs("vault-item-type").value;
    const label = qs("vault-item-label").value.trim();
    if (!label) {
      alert("Please enter a service / account label.");
      return;
    }

    const payload = {
      id: qs("vault-item-id").value || "",
      type: type,
      label: label,
      notes: qs("vault-item-notes").value.trim(),
    };

    if (type === "totp") {
      const secret = qs("vault-item-secret").value.trim().replace(/\s+/g, "").toUpperCase();
      if (!secret) {
        alert("Please enter a Base32 2FA secret key.");
        return;
      }
      payload.secret = secret;
      payload.digits = Number(qs("vault-item-digits").value || 6);
      payload.period = Number(qs("vault-item-period").value || 30);
    } else {
      payload.user = qs("vault-item-user").value.trim();
      payload.pass = qs("vault-item-pass").value;
    }

    try {
      const res = await api("/api/vault/entry/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        alert("Failed to save entry: " + (errJson.error || res.status));
        return;
      }
      closeVaultModal();
      await loadVaultEntries();
    } catch (_) {
      alert("Failed to save entry – network error.");
    }
  });

  // Backup Export & Import Controls
  qs("vault-export-backup-btn")?.addEventListener("click", async () => {
    try {
      setText("vault-backup-status-msg", "Generating AES-256-GCM encrypted backup on hardware...");
      const res = await api("/api/vault/backup/export");
      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        setText("vault-backup-status-msg", errJson.error || "Failed to download backup.");
        return;
      }
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      const dateStr = new Date().toISOString().slice(0, 10);
      a.download = `esp32_hardware_vault_backup_${dateStr}.esp32vault`;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        window.URL.revokeObjectURL(url);
        a.remove();
      }, 2000);
      setText("vault-backup-status-msg", "✅ Backup downloaded successfully. Keep this file safe!");
    } catch (err) {
      setText("vault-backup-status-msg", "Download error: " + err.message);
    }
  });

  let pendingBackupBase64 = "";
  const fileInput = qs("vault-backup-file-input");
  const restoreModal = qs("vault-restore-modal");

  qs("vault-import-backup-btn")?.addEventListener("click", () => {
    fileInput?.click();
  });

  fileInput?.addEventListener("change", (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      pendingBackupBase64 = reader.result;
      if (restoreModal) {
        setValue("vault-restore-pass", "");
        setText("vault-restore-status", "");
        restoreModal.classList.remove("hidden");
      }
    };
    reader.readAsDataURL(file);
    fileInput.value = "";
  });

  qs("vault-restore-modal-close")?.addEventListener("click", () => {
    restoreModal?.classList.add("hidden");
  });
  qs("vault-restore-cancel-btn")?.addEventListener("click", () => {
    restoreModal?.classList.add("hidden");
  });

  qs("vault-restore-confirm-btn")?.addEventListener("click", async () => {
    const password = qs("vault-restore-pass")?.value || "";
    if (!pendingBackupBase64) return;

    try {
      setText("vault-restore-status", "Authenticating & decrypting backup on hardware...");
      const res = await api("/api/vault/backup/import", {
        method: "POST",
        body: JSON.stringify({ backupBase64: pendingBackupBase64, password })
      });
      const data = await res.json();
      if (!res.ok) {
        setText("vault-restore-status", data.error || "Failed to restore backup.");
        return;
      }
      restoreModal?.classList.add("hidden");
      setText("vault-backup-status-msg", `✅ Restored ${data.restored_totp ?? 0} 2FA/vault items & ${data.restored_passkeys ?? 0} FIDO2 passkeys!`);
      await refreshVaultView();
    } catch (err) {
      setText("vault-restore-status", "Error restoring backup.");
    }
  });

  // Passkey Inspector Controls
  qs("fido-inspect-close")?.addEventListener("click", closeFidoInspectModal);
  qs("fido-inspect-close-btn")?.addEventListener("click", closeFidoInspectModal);
  qs("inspect-copy-cred-id")?.addEventListener("click", () => {
    const val = qs("inspect-cred-id")?.value;
    if (val) copyTextToClipboard(val, "Credential ID copied.");
  });
  qs("inspect-copy-pub-key")?.addEventListener("click", () => {
    const val = qs("inspect-pub-key")?.value;
    if (val) copyTextToClipboard(val, "Public Key coordinates copied.");
  });

  bindYubiKeyEvents();
}

function setupTabs() {
  const buttons = Array.from(document.querySelectorAll(".tab-btn"));
  const views = Array.from(document.querySelectorAll(".view"));

  async function activate(tab) {
    if (
      activeTab === "keyboard"
      && tab !== "keyboard"
      && keyboardPrefs.autoReleaseOnTabSwitch
    ) {
      try {
        await sendKeyboardEvent("release_all", null, null, false);
      } catch (_) {}
      lockedModifiers.clear();
      pointerPressedKeys.clear();
      document.querySelectorAll(".mod-lock").forEach((btn) => btn.classList.remove("active"));
      document.querySelectorAll(".vk-key.active").forEach((btn) => btn.classList.remove("active"));
    }

    activeTab = tab;
    sessionStorage.setItem("active_tab", tab);
    buttons.forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
    views.forEach((v) => v.classList.toggle("active", v.id === `view-${tab}`));

    if (tab === "settings") {
      loadSettings();
      loadSystemLogs();
    } else if (tab === "kvm") {
      loadKvmStatus();
      loadActionFiles();
    } else if (tab === "vault") {
      refreshVaultView();
    }
  }

  buttons.forEach((button) => {
    button.addEventListener("click", () => activate(button.dataset.tab));
  });

  const savedTab = sessionStorage.getItem("active_tab");
  if (savedTab && document.getElementById(`view-${savedTab}`)) {
    activate(savedTab);
  }
}

function bindQuickActionButtons() {
  document.querySelectorAll("[data-action-key]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const code = Number(btn.dataset.actionKey);
      if (!Number.isFinite(code)) return;
      sendKeyTap(code);
    });
  });

  document.querySelectorAll("[data-action-combo]").forEach((btn) => {
    btn.addEventListener("click", () => {
      sendCombo(btn.dataset.actionCombo);
    });
  });
}

function initEvents() {
  qs("new-file-btn").addEventListener("click", createNewFile);
  qs("save-btn").addEventListener("click", saveCurrentFile);
  qs("run-btn").addEventListener("click", runScript);
  qs("delete-btn").addEventListener("click", deleteCurrentFile);
  qs("download-btn").addEventListener("click", downloadCurrentFile);
  qs("stop-btn").addEventListener("click", stopScript);

  qs("inject-btn").addEventListener("click", injectLiveText);
  qs("clear-live-btn").addEventListener("click", () => {
    qs("live-text").value = "";
    setText("remote-status", "Cleared.");
  });

  qs("add-custom-action-btn").addEventListener("click", addCustomAction);

  qs("export-pref-btn").addEventListener("click", exportPreferenceBundle);
  qs("import-pref-btn").addEventListener("click", () => qs("import-pref-input").click());
  qs("import-pref-input").addEventListener("change", async (event) => {
    const file = event.target.files && event.target.files[0];
    event.target.value = "";
    if (!file) return;

    try {
      await importPreferenceBundle(file);
    } catch (_) {
      setText("remote-status", "Invalid preference file.");
    }
  });

  qs("save-kvm-btn").addEventListener("click", saveKvmConfig);
  qs("refresh-kvm-btn").addEventListener("click", loadKvmStatus);
  qs("kvm-release-all-btn").addEventListener("click", releaseAllHid);

  qs("copy-kvm-cmd-main").addEventListener("click", () => {
    copyTextToClipboard(qs("kvm-cmd-main").value, "Shared mode command copied.");
  });
  qs("copy-kvm-cmd-no-preview").addEventListener("click", () => {
    copyTextToClipboard(qs("kvm-cmd-no-preview").value, "Exclusive mode command copied.");
  });
  qs("copy-target-capture-cmd").addEventListener("click", () => {
    copyTextToClipboard(qs("target-capture-cmd").value, "Target capture command copied.");
  });

  qs("load-screenshot-btn").addEventListener("click", loadScreenshotPreview);
  qs("open-screenshot-url-btn").addEventListener("click", () => {
    const url = qs("screenshot-url").value.trim();
    if (!url) return;
    window.open(url, "_blank", "noopener,noreferrer");
  });

  qs("screenshot-auto-refresh").addEventListener("change", syncScreenshotAutoRefresh);
  qs("screenshot-interval-ms").addEventListener("change", syncScreenshotAutoRefresh);

  qs("record-start-btn").addEventListener("click", startRecording);
  qs("record-stop-btn").addEventListener("click", stopRecording);
  qs("record-clear-btn").addEventListener("click", clearRecording);
  qs("record-download-btn").addEventListener("click", downloadRecordingFile);
  qs("record-save-device-btn").addEventListener("click", saveRecordingToDevice);
  qs("record-source").addEventListener("change", () => {
    const source = getRecordSource();
    recorder.source = source;
    if (source === "kvm_bridge") {
      loadBridgeRecordStatus();
      setText("record-status", "Source set to KVM Bridge. Click Start Recording to capture incoming packets.");
    } else {
      setText("record-status", "Source set to Web UI.");
    }
  });
  qs("action-run-btn").addEventListener("click", runSelectedActionFile);
  qs("action-delete-btn").addEventListener("click", deleteSelectedActionFile);
  qs("action-refresh-btn").addEventListener("click", loadActionFiles);

  qs("action-import-btn").addEventListener("click", () => qs("action-import-input").click());
  qs("action-import-input").addEventListener("change", async (event) => {
    const file = event.target.files && event.target.files[0];
    event.target.value = "";
    if (!file) return;

    try {
      await importActionFileToDevice(file);
    } catch (_) {
      setText("record-status", "Failed to import action file.");
    }
  });

  qs("save-settings-btn").addEventListener("click", saveSettings);
  qs("reboot-btn").addEventListener("click", rebootDevice);
  qs("logout-btn").addEventListener("click", logout);

  qs("generate-proxy-token").addEventListener("click", () => {
    qs("proxy-auth-token").value = generateRandomToken(48);
    setText("settings-status", "Generated a new proxy token. Save settings to apply.");
  });

  qs("usb-vendor-preset").addEventListener("change", () => {
    applyVendorPreset(qs("usb-vendor-preset").value);
  });

  ["usb-vendor-name", "usb-vendor-id", "usb-product-id"].forEach((id) => {
    qs(id).addEventListener("input", () => {
      qs("usb-vendor-preset").value = "custom";
    });
  });

  bindSliderReadout("typing-delay", " ms");
  bindSliderReadout("burst-chars", "");
  bindSliderReadout("burst-pause", " ms");
  bindSliderReadout("line-delay", " ms");
  bindSliderReadout("kvm-mouse-smooth", "%");
  bindSpeedPresets();

  qs("usb-msc-enabled")?.addEventListener("change", (e) => {
    const mscBadge = qs("usb-msc-status-badge");
    if (mscBadge) {
      mscBadge.textContent = e.target.checked ? "Enabled" : "Disabled";
      mscBadge.className = e.target.checked ? "badge ok" : "badge";
    }
  });

  qs("ble-fido-enabled")?.addEventListener("change", (e) => {
    const bleBadge = qs("ble-fido-status-badge");
    if (bleBadge) {
      bleBadge.textContent = e.target.checked ? "Active" : "Disabled";
      bleBadge.className = e.target.checked ? "badge ok" : "badge";
    }
  });

  qs("refresh-net-btn").addEventListener("click", () => {
    loadSettings();
    refreshStatus();
  });
  qs("net-copy-sta-ip").addEventListener("click", () => {
    const ip = qs("net-sta-ip").textContent;
    if (ip && ip !== "Not Connected") {
      copyTextToClipboard("http://" + ip, "Home WiFi IP link copied.");
    }
  });
  qs("net-open-sta-ip").addEventListener("click", () => {
    const ip = qs("net-sta-ip").textContent;
    if (ip && ip !== "Not Connected") {
      window.open("http://" + ip, "_blank");
    }
  });
  qs("net-copy-ap-ip")?.addEventListener("click", () => {
    const ip = qs("net-ap-ip").textContent;
    if (ip) copyTextToClipboard("http://" + ip, "AP IP link copied.");
  });

  qs("net-open-mdns")?.addEventListener("click", () => {
    window.open("http://ducky.local", "_blank");
  });

  bindVaultEvents();
  updateKvmHelperPanel();

  qs("msc-refresh-btn")?.addEventListener("click", loadMscFiles);
  qs("msc-rebuild-btn")?.addEventListener("click", rebuildUsbDrive);
  qs("msc-reset-default-btn")?.addEventListener("click", resetMscDefault);
  qs("stage-selected-script-btn")?.addEventListener("click", stageCurrentScriptToMsc);
}

async function bootstrap() {
  setupTabs();
  loadKeyboardPrefs();
  initEvents();
  bindQuickActionButtons();
  bindHelpPanel();

  renderKeyboard65();
  bindModifierLocks();
  bindTrackpad();
  bindAbsoluteMouse();
  bindOtaControls();
  bindSystemLogs();
  bindFidoControls();
  bindKeyboardPreferenceControls();
  startMouseFlushLoop();

  loadCustomActions();
  renderCustomActions();
  applyKeyboardPrefsToUI();

  await loadFiles();
  await loadMscFiles();
  await refreshStatus();
  await loadKvmStatus();
  await loadActionFiles();
  await refreshVaultView();
  syncScreenshotAutoRefresh();

  statusPollTimer = setInterval(() => {
    refreshStatus();
    if (activeTab === "kvm") {
      loadKvmStatus();
    }
  }, 1300);
}

window.addEventListener("beforeunload", () => {
  if (statusPollTimer) clearInterval(statusPollTimer);
  if (mouseFlushTimer) clearInterval(mouseFlushTimer);
  if (sysLogTimer) clearInterval(sysLogTimer);
  stopScreenshotAutoRefresh();
  cleanupScreenshotObjectUrl();
});

bootstrap();
